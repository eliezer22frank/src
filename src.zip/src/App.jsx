import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider, createTheme, Box } from '@mui/material';
import { useState, useEffect } from 'react';

// Componentes principales
import Navbar from './components/layout/Navbar';
import Home from './pages/Home';
import Profile from './pages/Profile';
import Chat from './pages/Chat';
import Matches from './pages/Matches';
import Login from './pages/Login';
import Register from './pages/Register';
import Discover from './pages/Discover';
import SearchPreferences from './pages/SearchPreferences';
import AccountCenter from './pages/AccountCenter';
import Notifications from './pages/Notifications';
import Blocked from './pages/Blocked';

const theme = createTheme({
  palette: {
    primary: {
      main: '#ff4b4b',
    },
    secondary: {
      main: '#ff758c',
    },
  },
});

function App() {
  // Verificar si hay una sesión guardada en localStorage
  const [isAuthenticated, setIsAuthenticated] = useState(() => {
    return localStorage.getItem('isAuthenticated') === 'true';
  });
  
  // Guardar el estado de autenticación en localStorage cuando cambie
  useEffect(() => {
    localStorage.setItem('isAuthenticated', isAuthenticated);
  }, [isAuthenticated]);

  return (
    <ThemeProvider theme={theme}>
      <Router>
        <Box sx={{ pb: isAuthenticated ? 7 : 0 }}> {/* Padding bottom solo cuando el Navbar está visible */}
          <Routes>
            <Route path="/login" element={
              isAuthenticated ? <Navigate to="/" replace /> : <Login setIsAuthenticated={setIsAuthenticated} />
            } />
            <Route path="/register" element={
              isAuthenticated ? <Navigate to="/" replace /> : <Register setIsAuthenticated={setIsAuthenticated} />
            } />
            <Route path="/" element={
              isAuthenticated ? <Home /> : <Navigate to="/login" replace />
            } />
            <Route path="/profile" element={
              isAuthenticated ? <Profile /> : <Navigate to="/login" replace />
            } />
            <Route path="/chat" element={
              isAuthenticated ? <Chat /> : <Navigate to="/login" replace />
            } />
            <Route path="/matches" element={
              isAuthenticated ? <Matches /> : <Navigate to="/login" replace />
            } />
            <Route path="/discover" element={
              isAuthenticated ? <Discover /> : <Navigate to="/login" replace />
            } />
            <Route path="/search-preferences" element={
              isAuthenticated ? <SearchPreferences /> : <Navigate to="/login" replace />
            } />
            <Route path="/account-center" element={
              isAuthenticated ? <AccountCenter /> : <Navigate to="/login" replace />
            } />
            <Route path="/notifications" element={
              isAuthenticated ? <Notifications /> : <Navigate to="/login" replace />
            } />
            <Route path="/blocked" element={
              isAuthenticated ? <Blocked /> : <Navigate to="/login" replace />
            } />
          </Routes>
          {isAuthenticated && <Navbar />} {/* Navbar solo visible cuando el usuario está autenticado */}
        </Box>
      </Router>
    </ThemeProvider>
  );
}

export default App;