import { AppBar, Toolbar, IconButton, Typography, Badge, Avatar, Box, Paper, Menu, MenuItem, Divider } from '@mui/material';
import { Home, Chat, Favorite, Person, Explore, ExitToApp, Settings, AccountCircle, Notifications, Block, DeleteForever } from '@mui/icons-material';
import { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';

const Navbar = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [anchorEl, setAnchorEl] = useState(null);
  const [profileImage, setProfileImage] = useState('https://source.unsplash.com/random/400x400/?portrait');
  
  // Cargar la imagen de perfil desde localStorage si existe
  useEffect(() => {
    const savedProfile = localStorage.getItem('userProfile');
    if (savedProfile) {
      try {
        const parsedProfile = JSON.parse(savedProfile);
        if (parsedProfile.photos && parsedProfile.photos.length > 0) {
          setProfileImage(parsedProfile.photos[0]);
        }
      } catch (error) {
        console.error('Error al cargar la imagen de perfil:', error);
      }
    }
  }, []);
  
  const handleProfileClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };
  
  const handleLogout = () => {
    // Eliminar la sesión del localStorage
    localStorage.removeItem('isAuthenticated');
    // Recargar la página para que se apliquen los cambios
    window.location.href = '/login';
    handleClose();
  };

  return (
    <AppBar position="fixed" sx={{ top: 'auto', bottom: 0, bgcolor: '#121212', height: 'auto' }}>
      <Paper elevation={3} sx={{ width: '100%', bgcolor: '#121212' }}>
        <Toolbar sx={{ justifyContent: 'space-around', padding: '4px 0', minHeight: '48px' }}>
          <IconButton 
            color="inherit" 
            onClick={() => navigate('/')} 
            sx={{ 
              display: 'flex', 
              flexDirection: 'column', 
              alignItems: 'center',
              color: location.pathname === '/' ? 'secondary.main' : 'white'
            }}
          >
            <Home fontSize="small" />
            <Typography variant="caption" sx={{ fontSize: '0.65rem' }}>Inicio</Typography>
          </IconButton>

          <IconButton 
            color="inherit" 
            onClick={() => navigate('/discover')} 
            sx={{ 
              display: 'flex', 
              flexDirection: 'column', 
              alignItems: 'center',
              color: location.pathname === '/discover' ? 'secondary.main' : 'white'
            }}
          >
            <Explore fontSize="small" />
            <Typography variant="caption" sx={{ fontSize: '0.65rem' }}>Descubrir</Typography>
          </IconButton>

          <IconButton 
            color="inherit" 
            onClick={() => navigate('/matches')} 
            sx={{ 
              display: 'flex', 
              flexDirection: 'column', 
              alignItems: 'center',
              color: location.pathname === '/matches' ? 'secondary.main' : 'white'
            }}
          >
            <Badge badgeContent={4} color="secondary">
              <Favorite fontSize="small" />
            </Badge>
            <Typography variant="caption" sx={{ fontSize: '0.65rem' }}>Matches</Typography>
          </IconButton>

          <IconButton 
            color="inherit" 
            onClick={() => navigate('/chat')} 
            sx={{ 
              display: 'flex', 
              flexDirection: 'column', 
              alignItems: 'center',
              color: location.pathname === '/chat' ? 'secondary.main' : 'white'
            }}
          >
            <Badge badgeContent={2} color="secondary">
              <Chat fontSize="small" />
            </Badge>
            <Typography variant="caption" sx={{ fontSize: '0.65rem' }}>Chat</Typography>
          </IconButton>

          <IconButton 
            color="inherit" 
            onClick={handleProfileClick} 
            sx={{ 
              display: 'flex', 
              flexDirection: 'column', 
              alignItems: 'center',
              color: location.pathname === '/profile' ? 'secondary.main' : 'white'
            }}
          >
            <Avatar 
              src={profileImage} 
              sx={{ 
                width: 24, 
                height: 24, 
                border: location.pathname === '/profile' ? '2px solid #f50057' : '2px solid transparent'
              }}
            />
            <Typography variant="caption" sx={{ fontSize: '0.65rem' }}>Perfil</Typography>
          </IconButton>
          
          <Menu
            anchorEl={anchorEl}
            open={Boolean(anchorEl)}
            onClose={handleClose}
            PaperProps={{
              sx: {
                backgroundColor: '#1e1e1e',
                color: 'white',
                boxShadow: '0 4px 10px rgba(0, 0, 0, 0.3)',
                minWidth: '200px'
              }
            }}
          >
            <MenuItem onClick={() => { navigate('/profile'); handleClose(); }}>
              <Person fontSize="small" sx={{ mr: 1 }} />
              <Typography>Perfil</Typography>
            </MenuItem>
            <MenuItem onClick={() => { navigate('/search-preferences'); handleClose(); }}>
              <Settings fontSize="small" sx={{ mr: 1 }} />
              <Typography>Preferencias de búsqueda</Typography>
            </MenuItem>
            <MenuItem onClick={() => { navigate('/account-center'); handleClose(); }}>
              <AccountCircle fontSize="small" sx={{ mr: 1 }} />
              <Typography>Centro de cuentas</Typography>
            </MenuItem>
            <MenuItem onClick={() => { navigate('/notifications'); handleClose(); }}>
              <Notifications fontSize="small" sx={{ mr: 1 }} />
              <Typography>Notificaciones</Typography>
            </MenuItem>
            <Divider sx={{ my: 1, backgroundColor: 'rgba(255, 255, 255, 0.1)' }} />
            <MenuItem onClick={handleLogout}>
              <ExitToApp fontSize="small" sx={{ mr: 1 }} />
              <Typography>Cerrar sesión</Typography>
            </MenuItem>
          </Menu>
        </Toolbar>
      </Paper>
    </AppBar>
  );
};

export default Navbar;