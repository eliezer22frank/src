import { useState, useEffect } from 'react';
import {
  Box,
  Container,
  Paper,
  Typography,
  IconButton,
  FormControl,
  OutlinedInput,
  MenuItem,
  Grid
} from '@mui/material';
import { ArrowBack } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';

const SearchPreferences = () => {
  const navigate = useNavigate();
  const [searchPreferences, setSearchPreferences] = useState({
    ageRange: [18, 40],
    distance: 25,
    sexualOrientation: 'Heterosexual',
    lookingFor: 'Relación seria'
  });
  
  // Cargar preferencias desde localStorage al iniciar
  useEffect(() => {
    const savedProfile = localStorage.getItem('userProfile');
    if (savedProfile) {
      try {
        const parsedProfile = JSON.parse(savedProfile);
        if (parsedProfile.searchPreferences) {
          setSearchPreferences({
            ...searchPreferences,
            ...parsedProfile.searchPreferences,
            sexualOrientation: parsedProfile.sexualOrientation || searchPreferences.sexualOrientation,
            lookingFor: parsedProfile.lookingFor || searchPreferences.lookingFor
          });
        }
      } catch (error) {
        console.error('Error al cargar las preferencias:', error);
      }
    }
  }, []);

  // Guardar cambios en localStorage
  const savePreferences = () => {
    const savedProfile = localStorage.getItem('userProfile');
    if (savedProfile) {
      try {
        const parsedProfile = JSON.parse(savedProfile);
        const updatedProfile = {
          ...parsedProfile,
          searchPreferences: {
            ageRange: searchPreferences.ageRange,
            distance: searchPreferences.distance
          },
          sexualOrientation: searchPreferences.sexualOrientation,
          lookingFor: searchPreferences.lookingFor
        };
        localStorage.setItem('userProfile', JSON.stringify(updatedProfile));
        console.log('Preferencias guardadas:', updatedProfile);
      } catch (error) {
        console.error('Error al guardar las preferencias:', error);
      }
    } else {
      // Si no hay perfil, crear uno nuevo con las preferencias
      const newProfile = {
        searchPreferences: {
          ageRange: searchPreferences.ageRange,
          distance: searchPreferences.distance
        },
        sexualOrientation: searchPreferences.sexualOrientation,
        lookingFor: searchPreferences.lookingFor
      };
      localStorage.setItem('userProfile', JSON.stringify(newProfile));
    }
  };

  // Guardar automáticamente cuando cambian las preferencias
  useEffect(() => {
    savePreferences();
  }, [searchPreferences]);

  return (
    <Box
      sx={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#000000',
        position: 'relative'
      }}
    >
      <Container maxWidth="sm" sx={{ position: 'relative', zIndex: 2 }}>
        <Paper 
          sx={{ 
            p: 0, 
            overflow: 'hidden',
            backgroundColor: '#1e1e1e',
            borderRadius: '8px',
            boxShadow: '0 4px 10px rgba(0, 0, 0, 0.3)',
            color: 'white',
            position: 'relative',
            maxWidth: 400,
            mx: 'auto'
          }}
        >
          {/* Encabezado */}
          <Box sx={{ 
            p: 2, 
            bgcolor: '#333333', 
            display: 'flex', 
            alignItems: 'center',
            borderBottom: '1px solid rgba(128, 128, 128, 0.4)'
          }}>
            <IconButton sx={{ color: 'white' }} onClick={() => navigate(-1)}>
              <ArrowBack />
            </IconButton>
            <Typography variant="h6" sx={{ color: 'white', fontWeight: 'bold', mx: 'auto' }}>
              Preferencias de Búsqueda
            </Typography>
          </Box>

          <Box sx={{ p: 3 }}>
            {/* Sección de Preferencias de Búsqueda */}
            <Typography variant="body2" sx={{ color: '#808080', mb: 0.5, fontWeight: 'bold', fontSize: '0.8rem' }}>
              Rango de edad:
            </Typography>
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
              <Typography variant="body2" sx={{ color: 'white', mr: 1 }}>
                {searchPreferences.ageRange[0]}
              </Typography>
              <Box sx={{ flex: 1, px: 1 }}>
                <input
                  type="range"
                  min="18"
                  max="65"
                  value={searchPreferences.ageRange[0]}
                  onChange={(e) => {
                    const value = parseInt(e.target.value);
                    setSearchPreferences({
                      ...searchPreferences,
                      ageRange: [value, searchPreferences.ageRange[1]]
                    });
                  }}
                  style={{ width: '100%' }}
                />
              </Box>
              <Typography variant="body2" sx={{ color: 'white', ml: 1 }}>
                {searchPreferences.ageRange[1]}
              </Typography>
              <Box sx={{ flex: 1, px: 1 }}>
                <input
                  type="range"
                  min="18"
                  max="65"
                  value={searchPreferences.ageRange[1]}
                  onChange={(e) => {
                    const value = parseInt(e.target.value);
                    setSearchPreferences({
                      ...searchPreferences,
                      ageRange: [searchPreferences.ageRange[0], value]
                    });
                  }}
                  style={{ width: '100%' }}
                />
              </Box>
            </Box>

            <Typography variant="body2" sx={{ color: '#808080', mb: 0.5, fontWeight: 'bold', fontSize: '0.8rem' }}>
              Distancia máxima (km):
            </Typography>
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
              <Typography variant="body2" sx={{ color: 'white', mr: 1 }}>
                5
              </Typography>
              <Box sx={{ flex: 1, px: 1 }}>
                <input
                  type="range"
                  min="5"
                  max="100"
                  value={searchPreferences.distance}
                  onChange={(e) => {
                    const value = parseInt(e.target.value);
                    setSearchPreferences({
                      ...searchPreferences,
                      distance: value
                    });
                  }}
                  style={{ width: '100%' }}
                />
              </Box>
              <Typography variant="body2" sx={{ color: 'white', ml: 1 }}>
                {searchPreferences.distance}
              </Typography>
            </Box>

            <Typography variant="body2" sx={{ color: '#808080', mb: 0.5, fontWeight: 'bold', fontSize: '0.8rem' }}>
              Orientación sexual:
            </Typography>
            <FormControl fullWidth variant="outlined" sx={{ mb: 2 }}>
              <OutlinedInput
                select
                fullWidth
                value={searchPreferences.sexualOrientation}
                onChange={(e) => {
                  setSearchPreferences({
                    ...searchPreferences,
                    sexualOrientation: e.target.value
                  });
                }}
                input={<OutlinedInput />}
                sx={{
                  '&:hover .MuiOutlinedInput-notchedOutline': {
                    borderColor: '#666666',
                  },
                  '& .MuiOutlinedInput-notchedOutline': {
                    borderColor: '#444444',
                    borderWidth: '1px',
                  },
                  '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                    borderColor: '#666666',
                    borderWidth: '2px',
                  },
                  borderRadius: '8px',
                  backgroundColor: 'rgba(0, 0, 0, 0.8)',
                  height: '45px',
                  color: 'white'
                }}
                renderValue={(selected) => selected}
              >
                {['Heterosexual', 'Homosexual', 'Bisexual', 'Pansexual', 'Asexual', 'Otro'].map((option) => (
                  <MenuItem key={option} value={option}>
                    {option}
                  </MenuItem>
                ))}
              </OutlinedInput>
            </FormControl>

            <Typography variant="body2" sx={{ color: '#808080', mb: 0.5, fontWeight: 'bold', fontSize: '0.8rem' }}>
              Buscando:
            </Typography>
            <FormControl fullWidth variant="outlined" sx={{ mb: 2 }}>
              <OutlinedInput
                select
                fullWidth
                value={searchPreferences.lookingFor}
                onChange={(e) => {
                  setSearchPreferences({
                    ...searchPreferences,
                    lookingFor: e.target.value
                  });
                }}
                input={<OutlinedInput />}
                sx={{
                  '&:hover .MuiOutlinedInput-notchedOutline': {
                    borderColor: '#666666',
                  },
                  '& .MuiOutlinedInput-notchedOutline': {
                    borderColor: '#444444',
                    borderWidth: '1px',
                  },
                  '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                    borderColor: '#666666',
                    borderWidth: '2px',
                  },
                  borderRadius: '8px',
                  backgroundColor: 'rgba(0, 0, 0, 0.8)',
                  height: '45px',
                  color: 'white'
                }}
                renderValue={(selected) => selected}
              >
                {['Relación seria', 'Relación casual', 'Amistad', 'Networking', 'No estoy seguro/a'].map((option) => (
                  <MenuItem key={option} value={option}>
                    {option}
                  </MenuItem>
                ))}
              </OutlinedInput>
            </FormControl>
          </Box>
        </Paper>
      </Container>
    </Box>
  );
};

export default SearchPreferences;