import { useState } from 'react';
import { Box, Card, CardContent, CardMedia, Typography, IconButton, Stack, Modal, Grid, Chip, Divider, Button } from '@mui/material';
import { Favorite, Close, Info, LocationOn, School, Work, Interests } from '@mui/icons-material';
import { motion, AnimatePresence } from 'framer-motion';

const mockProfiles = [
  {
    id: 1,
    name: 'Ana García',
    age: 28,
    bio: 'Amante de los viajes y la fotografía',
    fullBio: 'Soy una apasionada de los viajes y la fotografía. Me encanta explorar nuevos lugares, conocer diferentes culturas y capturar momentos especiales con mi cámara. Siempre estoy buscando nuevas aventuras y experiencias que me permitan crecer como persona.',
    image: 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?q=80&w=1471&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    additionalImages: [
      'https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3',
      'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=1376&auto=format&fit=crop&ixlib=rb-4.0.3',
      'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3'
    ],
    interests: ['Viajes', 'Fotografía', 'Música'],
    education: 'Licenciada en Bellas Artes, Universidad Complutense de Madrid',
    work: 'Fotógrafa freelance y guía turística',
    additionalInfo: 'Habla español, inglés y francés. Le encanta el senderismo y la cocina internacional.'
  },
  {
    id: 2,
    name: 'Carlos Rodríguez',
    age: 30,
    bio: 'Deportista y amante de la naturaleza',
    fullBio: 'Soy un apasionado del deporte y la vida al aire libre. Practico triatlón y me encanta hacer excursiones a la montaña. Creo firmemente que el contacto con la naturaleza es esencial para mantener un equilibrio físico y mental saludable.',
    image: 'https://images.unsplash.com/photo-1541752171745-4176eee47556?q=80&w=1470&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    additionalImages: [
      'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3',
      'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3',
      'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3'
    ],
    interests: ['Deportes', 'Naturaleza', 'Aventura'],
    education: 'Licenciado en Ciencias del Deporte, Universidad Politécnica de Madrid',
    work: 'Entrenador personal y guía de montaña',
    additionalInfo: 'Ha participado en varias competiciones de triatlón a nivel nacional. Amante de los animales y voluntario en protectoras.'
  },
  {
    id: 3,
    name: 'Laura Martínez',
    age: 25,
    bio: 'Artista y amante del yoga',
    fullBio: 'Soy artista plástica y profesora de yoga. Mi pasión es expresarme a través del arte y ayudar a otros a encontrar paz interior mediante la práctica del yoga. Creo que el equilibrio entre cuerpo y mente es fundamental para una vida plena.',
    image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3',
    additionalImages: [
      'https://images.unsplash.com/photo-1517841905240-472988babdf9?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3',
      'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=1376&auto=format&fit=crop&ixlib=rb-4.0.3',
      'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3'
    ],
    interests: ['Arte', 'Yoga', 'Meditación'],
    education: 'Graduada en Bellas Artes y certificada como instructora de yoga',
    work: 'Artista independiente y profesora de yoga',
    additionalInfo: 'Ha expuesto sus obras en varias galerías locales. Practica meditación diariamente y organiza retiros de yoga.'
  },
  {
    id: 4,
    name: 'Miguel Sánchez',
    age: 29,
    bio: 'Chef profesional y viajero incansable',
    fullBio: 'Soy chef profesional con especialidad en cocina mediterránea y asiática. Mi pasión por la gastronomía me ha llevado a viajar por todo el mundo en busca de nuevos sabores e ingredientes. Creo que la comida es una forma de conectar culturas y personas.',
    image: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3',
    additionalImages: [
      'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3',
      'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3',
      'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3'
    ],
    interests: ['Gastronomía', 'Viajes', 'Vino'],
    education: 'Graduado en la Escuela de Hostelería de Barcelona',
    work: 'Chef ejecutivo en restaurante de cocina fusión',
    additionalInfo: 'Ha trabajado en restaurantes con estrellas Michelin. Coleccionista de vinos y sommelier aficionado.'
  },
  {
    id: 5,
    name: 'Isabel López',
    age: 27,
    bio: 'Bailarina profesional y profesora de danza',
    fullBio: 'Soy bailarina profesional especializada en danza contemporánea y ballet clásico. Comencé a bailar a los 5 años y desde entonces ha sido mi pasión. Actualmente compagino mi carrera como bailarina con la enseñanza, transmitiendo mi amor por la danza a nuevas generaciones.',
    image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=1376&auto=format&fit=crop&ixlib=rb-4.0.3',
    additionalImages: [
      'https://images.unsplash.com/photo-1517841905240-472988babdf9?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3',
      'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3',
      'https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3'
    ],
    interests: ['Danza', 'Música', 'Teatro'],
    education: 'Conservatorio Superior de Danza de Madrid',
    work: 'Bailarina en compañía de danza contemporánea y profesora',
    additionalInfo: 'Ha participado en producciones internacionales y festivales de danza. Toca el piano en su tiempo libre.'
  },
  {
    id: 6,
    name: 'David Herrera',
    age: 31,
    bio: 'Músico y productor musical',
    fullBio: 'Soy músico profesional y productor musical con más de 10 años de experiencia en la industria. Me especializo en música electrónica y composición para medios audiovisuales. Mi estudio es mi segundo hogar, donde paso horas creando y experimentando con sonidos.',
    image: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3',
    additionalImages: [
      'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3',
      'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3',
      'https://images.unsplash.com/photo-1541752171745-4176eee47556?q=80&w=1470&auto=format&fit=crop&ixlib=rb-4.0.3'
    ],
    interests: ['Música', 'Tecnología', 'Cine'],
    education: 'Graduado en Producción Musical, Escuela Superior de Música',
    work: 'Productor musical freelance y compositor para publicidad',
    additionalInfo: 'Ha trabajado con artistas nacionales e internacionales. Toca varios instrumentos incluyendo piano, guitarra y batería.'
  },
  {
    id: 7,
    name: 'Carmen Ruiz',
    age: 26,
    bio: 'Diseñadora gráfica y ilustradora',
    fullBio: 'Soy diseñadora gráfica e ilustradora con un enfoque creativo y minimalista. Me apasiona crear identidades visuales para marcas y proyectos que buscan destacar. Mi trabajo combina técnicas tradicionales con herramientas digitales para lograr resultados únicos y memorables.',
    image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3',
    additionalImages: [
      'https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3',
      'https://images.unsplash.com/photo-1517841905240-472988babdf9?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3',
      'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=1376&auto=format&fit=crop&ixlib=rb-4.0.3'
    ],
    interests: ['Diseño', 'Arte', 'Fotografía'],
    education: 'Graduada en Diseño Gráfico, Escuela de Arte y Diseño',
    work: 'Diseñadora freelance para agencias y marcas independientes',
    additionalInfo: 'Ha publicado un libro de ilustraciones y participa regularmente en exposiciones de arte. Amante de los gatos y el café.'
  },
  {
    id: 8,
    name: 'Javier Torres',
    age: 28,
    bio: 'Ingeniero de software y gamer',
    fullBio: 'Soy ingeniero de software especializado en desarrollo de aplicaciones web y móviles. En mi tiempo libre soy un apasionado de los videojuegos y la cultura japonesa. Me encanta participar en hackathones y eventos de tecnología donde puedo conocer a personas con intereses similares.',
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3',
    additionalImages: [
      'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3',
      'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3',
      'https://images.unsplash.com/photo-1541752171745-4176eee47556?q=80&w=1470&auto=format&fit=crop&ixlib=rb-4.0.3'
    ],
    interests: ['Tecnología', 'Videojuegos', 'Anime'],
    education: 'Ingeniero Informático, Universidad Politécnica de Madrid',
    work: 'Desarrollador Full Stack en empresa de tecnología',
    additionalInfo: 'Contribuye a proyectos de código abierto. Ha desarrollado varios juegos indie en su tiempo libre.'
  },
  {
    id: 9,
    name: 'Elena Morales',
    age: 24,
    bio: 'Estudiante de medicina y voluntaria',
    fullBio: 'Soy estudiante de último año de medicina y dedico gran parte de mi tiempo libre al voluntariado en hospitales y organizaciones humanitarias. Mi sueño es especializarme en pediatría y poder trabajar en proyectos de cooperación internacional para ayudar a niños en zonas desfavorecidas.',
    image: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3',
    additionalImages: [
      'https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3',
      'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=1376&auto=format&fit=crop&ixlib=rb-4.0.3',
      'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3'
    ],
    interests: ['Medicina', 'Voluntariado', 'Lectura'],
    education: 'Estudiante de Medicina, Universidad Complutense de Madrid',
    work: 'Voluntaria en hospital infantil y ONG médica',
    additionalInfo: 'Ha participado en misiones humanitarias en África. Habla español, inglés y francés. Apasionada de la literatura clásica.'
  },
  {
    id: 10,
    name: 'Pablo Navarro',
    age: 32,
    bio: 'Fotógrafo profesional y aventurero',
    fullBio: 'Soy fotógrafo profesional especializado en fotografía de naturaleza y viajes. He recorrido más de 40 países capturando paisajes y culturas. Mi cámara es mi mejor compañera de aventuras y a través de ella intento transmitir la belleza y diversidad de nuestro planeta.',
    image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3',
    additionalImages: [
      'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3',
      'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3',
      'https://images.unsplash.com/photo-1541752171745-4176eee47556?q=80&w=1470&auto=format&fit=crop&ixlib=rb-4.0.3'
    ],
    interests: ['Fotografía', 'Aventura', 'Viajes'],
    education: 'Graduado en Comunicación Audiovisual, Universidad de Barcelona',
    work: 'Fotógrafo freelance para National Geographic y revistas de viajes',
    additionalInfo: 'Ha publicado dos libros de fotografía. Imparte talleres de fotografía de viajes y naturaleza. Amante del senderismo y la escalada.'
  }
];

const Home = () => {
  const [currentProfileIndex, setCurrentProfileIndex] = useState(0);
  const [direction, setDirection] = useState(null);
  const [openModal, setOpenModal] = useState(false);
  const currentProfile = mockProfiles[currentProfileIndex];

  const handleLike = () => {
    // Aquí irá la lógica para dar like y crear match
    console.log('Like:', currentProfile.id);
    setDirection('right');
    if (currentProfileIndex < mockProfiles.length - 1) {
      setTimeout(() => {
        setCurrentProfileIndex(prev => prev + 1);
      }, 300);
    }
  };

  const handleDislike = () => {
    // Aquí irá la lógica para descartar el perfil
    console.log('Dislike:', currentProfile.id);
    setDirection('left');
    if (currentProfileIndex < mockProfiles.length - 1) {
      setTimeout(() => {
        setCurrentProfileIndex(prev => prev + 1);
      }, 300);
    }
  };

  const handleInfo = () => {
    // Abre el modal con información detallada
    setOpenModal(true);
    console.log('Info:', currentProfile.id);
  };

  const handleCloseModal = () => {
    setOpenModal(false);
  };

  return (
    <Box sx={{ 
      height: '100vh', 
      display: 'flex', 
      flexDirection: 'column',
      justifyContent: 'center', 
      alignItems: 'center',
      bgcolor: '#1a1a1a',
      overflow: 'hidden', // Evita scroll
      pt: { xs: 2, sm: 3 }, // Padding top para evitar que se cubra por la navegación
      pb: { xs: 2, sm: 3 } // Padding bottom para espacio inferior
    }}>
      {/* Modal de información detallada */}
      <Modal
        open={openModal}
        onClose={handleCloseModal}
        aria-labelledby="modal-profile-details"
        aria-describedby="modal-profile-detailed-information"
      >
        <Box sx={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          width: { xs: '90%', sm: '80%', md: '70%' },
          maxWidth: 800,
          maxHeight: '90vh',
          bgcolor: '#1e1e1e',
          color: 'white',
          borderRadius: 2,
          boxShadow: 24,
          p: 4,
          overflow: 'auto'
        }}>
          <Typography variant="h4" component="h2" sx={{ mb: 3, fontWeight: 'bold' }}>
            {currentProfile.name}, {currentProfile.age}
          </Typography>
          
          <Grid container spacing={3}>
            {/* Galería de fotos */}
            <Grid item xs={12}>
              <Typography variant="h6" sx={{ mb: 2 }}>
                Galería de fotos
              </Typography>
              <Grid container spacing={2}>
                <Grid item xs={12} sm={6} md={4}>
                  <Box
                    component="img"
                    src={currentProfile.image}
                    alt={currentProfile.name}
                    sx={{
                      width: '100%',
                      height: 200,
                      objectFit: 'cover',
                      borderRadius: 2
                    }}
                  />
                </Grid>
                {currentProfile.additionalImages?.map((img, index) => (
                  <Grid item xs={12} sm={6} md={4} key={index}>
                    <Box
                      component="img"
                      src={img}
                      alt={`${currentProfile.name} ${index + 1}`}
                      sx={{
                        width: '100%',
                        height: 200,
                        objectFit: 'cover',
                        borderRadius: 2
                      }}
                    />
                  </Grid>
                ))}
              </Grid>
            </Grid>
            
            {/* Biografía completa */}
            <Grid item xs={12}>
              <Typography variant="h6" sx={{ mb: 1 }}>
                Biografía completa
              </Typography>
              <Typography variant="body1" sx={{ mb: 2 }}>
                {currentProfile.fullBio || currentProfile.bio}
              </Typography>
            </Grid>
            
            <Divider sx={{ width: '100%', my: 2, bgcolor: 'rgba(255,255,255,0.12)' }} />
            
            {/* Educación y trabajo */}
            <Grid item xs={12} sm={6}>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                <School sx={{ mr: 1 }} />
                <Typography variant="h6">
                  Educación
                </Typography>
              </Box>
              <Typography variant="body1" sx={{ mb: 2 }}>
                {currentProfile.education || 'No especificado'}
              </Typography>
            </Grid>
            
            <Grid item xs={12} sm={6}>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                <Work sx={{ mr: 1 }} />
                <Typography variant="h6">
                  Trabajo
                </Typography>
              </Box>
              <Typography variant="body1" sx={{ mb: 2 }}>
                {currentProfile.work || 'No especificado'}
              </Typography>
            </Grid>
            
            <Divider sx={{ width: '100%', my: 2, bgcolor: 'rgba(255,255,255,0.12)' }} />
            
            {/* Intereses */}
            <Grid item xs={12}>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                <Interests sx={{ mr: 1 }} />
                <Typography variant="h6">
                  Intereses
                </Typography>
              </Box>
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mb: 2 }}>
                {currentProfile.interests?.map((interest, index) => (
                  <Chip 
                    key={index} 
                    label={interest} 
                    sx={{ 
                      bgcolor: 'rgba(75, 75, 255, 0.2)', 
                      color: 'white',
                      '&:hover': { bgcolor: 'rgba(75, 75, 255, 0.3)' } 
                    }} 
                  />
                ))}
              </Box>
            </Grid>
            
            {/* Información adicional */}
            {currentProfile.additionalInfo && (
              <Grid item xs={12}>
                <Typography variant="h6" sx={{ mb: 1 }}>
                  Información adicional
                </Typography>
                <Typography variant="body1" sx={{ mb: 2 }}>
                  {currentProfile.additionalInfo}
                </Typography>
              </Grid>
            )}
          </Grid>
          
          <Box sx={{ mt: 4, display: 'flex', justifyContent: 'flex-end' }}>
            <Button 
              variant="contained" 
              onClick={handleCloseModal}
              sx={{ 
                bgcolor: '#4b4bff',
                '&:hover': { bgcolor: '#3a3acc' }
              }}
            >
              Cerrar
            </Button>
          </Box>
        </Box>
      </Modal>
      <AnimatePresence mode="wait">
        <motion.div
          key={currentProfile.id}
          initial={{ 
            x: direction === 'right' ? -300 : direction === 'left' ? 300 : 0,
            opacity: 0 
          }}
          animate={{ 
            x: 0, 
            opacity: 1 
          }}
          exit={{ 
            x: direction === 'right' ? 300 : direction === 'left' ? -300 : 0, 
            opacity: 0 
          }}
          transition={{ 
            type: 'spring', 
            stiffness: 300, 
            damping: 30 
          }}
          style={{ width: '100%', maxWidth: 500 }}
        >
      <Box sx={{ 
        width: '100%', 
        maxWidth: 500, 
        display: 'flex', 
        flexDirection: 'column', 
        gap: 1.5,
        height: 'calc(100vh - 100px)', // Altura ajustada para evitar scroll
        justifyContent: 'space-between' // Distribuye el espacio verticalmente
      }}>
      <Card sx={{ 
        width: '100%', 
        height: { xs: 'calc(100vh - 180px)', sm: 'calc(100vh - 200px)' }, // Altura responsiva
        position: 'relative', 
        bgcolor: 'transparent', 
        boxShadow: 'none',
        overflow: 'hidden' // Evita desbordamiento
      }}>
        <CardMedia
          component="img"
          sx={{
            height: '100%',
            width: '100%',
            objectFit: 'cover',
            borderRadius: 2
          }}
          image={currentProfile.image}
          alt={currentProfile.name}
        />
        <Box
          sx={{
            position: 'absolute',
            bottom: 0,
            left: 0,
            right: 0,
            background: 'linear-gradient(to top, rgba(0,0,0,0.9) 0%, rgba(0,0,0,0.5) 50%, rgba(0,0,0,0) 100%)',
            borderRadius: '0 0 8px 8px',
            p: 3,
            color: 'white'
          }}
        >
          <Stack spacing={1}>
            <Typography variant="h4" sx={{ fontWeight: 'bold' }}>
              {currentProfile.name}, {currentProfile.age}
            </Typography>
            <Stack direction="row" alignItems="center" spacing={1}>
              <LocationOn sx={{ fontSize: 20 }} />
              <Typography variant="body1">Madrid, España</Typography>
            </Stack>
            <Typography variant="body1" sx={{ opacity: 0.9 }}>
              {currentProfile.bio}
            </Typography>
            <Stack direction="row" spacing={1} flexWrap="wrap" sx={{ mt: 1 }}>
              {currentProfile.interests.map((interest) => (
                <Typography
                  key={interest}
                  variant="body2"
                  sx={{
                    bgcolor: 'rgba(255,255,255,0.2)',
                    color: 'white',
                    px: 1.5,
                    py: 0.5,
                    borderRadius: 2,
                    mb: 1
                  }}
                >
                  {interest}
                </Typography>
              ))}
            </Stack>
          </Stack>
        </Box>
      </Card>
      <Stack
        direction="row"
        spacing={2}
        justifyContent="center"
        sx={{
          zIndex: 2,
          mt: 'auto', // Empuja los botones hacia abajo
          mb: { xs: 1, sm: 2 } // Margen inferior responsivo
        }}
      >
          <IconButton
            onClick={handleDislike}
            sx={{
              bgcolor: 'white',
              width: 60,
              height: 60,
              '&:hover': { bgcolor: '#ffeded', transform: 'scale(1.1)' },
              transition: 'all 0.2s'
            }}
          >
            <Close sx={{ color: '#ff4b4b', fontSize: 30 }} />
          </IconButton>
          <IconButton
            onClick={handleInfo}
            sx={{
              bgcolor: 'white',
              width: 60,
              height: 60,
              '&:hover': { bgcolor: '#edf6ff', transform: 'scale(1.1)' },
              transition: 'all 0.2s'
            }}
          >
            <Info sx={{ color: '#4b4bff', fontSize: 30 }} />
          </IconButton>
          <IconButton
            onClick={handleLike}
            sx={{
              bgcolor: 'white',
              width: 60,
              height: 60,
              '&:hover': { bgcolor: '#edffed', transform: 'scale(1.1)' },
              transition: 'all 0.2s'
            }}
          >
            <Favorite sx={{ color: '#4bff4b', fontSize: 30 }} />
          </IconButton>
        </Stack>
      </Box>
        </motion.div>
      </AnimatePresence>
    </Box>
  );
};

export default Home;