import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Box, Card, CardContent, TextField, Button, Typography, Divider } from '@mui/material';
import { Google, Facebook } from '@mui/icons-material';

const Login = ({ setIsAuthenticated }) => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Para la demo, permitimos iniciar sesión sin verificar credenciales
    setIsAuthenticated(true);
    navigate('/');
  };

  // Función para iniciar sesión rápidamente (modo demo)
  const handleDemoLogin = () => {
    setIsAuthenticated(true);
    navigate('/');
  };

  const handleSocialLogin = (provider) => {
    // Aquí irá la lógica de autenticación social
    console.log(`Login with ${provider}`);
  };

  return (
    <Box
      sx={{
        height: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#000000',
        position: 'relative',
        '&::before': {
          content: '""',
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'radial-gradient(circle at 50% 50%, #1a1a1a 0%, #000000 100%)',
          opacity: 0.8,
          zIndex: 1
        },
        '&::after': {
          content: '""',
          position: 'absolute',
          top: '10%',
          left: '10%',
          width: '20px',
          height: '20px',
          background: 'linear-gradient(45deg, #ff69b4 0%, #ff1493 100%)',
          clipPath: 'path("M12 21.593c-5.63-5.539-11-10.297-11-14.402 0-3.791 3.068-5.191 5.281-5.191 1.312 0 4.151.501 5.719 4.457 1.59-3.968 4.464-4.447 5.726-4.447 2.54 0 5.274 1.621 5.274 5.181 0 4.069-5.136 8.625-11 14.402M5.999 3.001c-1.54 0-3.999.752-3.999 4.19 0 3.476 4.886 7.766 10 12.794 5.114-5.028 10-9.318 10-12.794 0-3.438-2.459-4.19-3.999-4.19-1.31 0-3.828.664-4.725 4.197l-1.275 3.803-1.275-3.803c-.897-3.533-3.415-4.197-4.725-4.197z")',
          zIndex: 0,
          animation: 'float 6s ease-in-out infinite'
        },
        '@keyframes float': {
          '0%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-20px)' },
          '100%': { transform: 'translateY(0px)' }
        }
      }}
    >
      <Card sx={{ 
        maxWidth: 400, 
        width: '100%', 
        mx: 2, 
        backgroundColor: '#1e1e1e',
        borderRadius: '8px',
        boxShadow: '0 4px 10px rgba(0, 0, 0, 0.3)',
        position: 'relative',
        zIndex: 2,
        border: '1px solid rgba(255, 255, 255, 0.1)'
      }}>
        <CardContent sx={{ p: 4 }}>
          <Typography variant="h4" component="h1" align="center" gutterBottom sx={{ color: 'white', fontWeight: 'bold' }}>
            Love
          </Typography>
          <Typography variant="body1" align="center" sx={{ color: '#aaaaaa', mb: 3 }}>
            Encuentra el amor de tu vida
          </Typography>

          <form onSubmit={handleSubmit}>
            <TextField
              fullWidth
              label="Correo electrónico"
              name="email"
              type="email"
              value={formData.email}
              onChange={handleChange}
              margin="normal"
              required
              sx={{
                '& .MuiOutlinedInput-root': {
                  '& fieldset': {
                    borderColor: '#444444',
                  },
                  '&:hover fieldset': {
                    borderColor: '#666666',
                  },
                  '&.Mui-focused fieldset': {
                    borderColor: '#888888',
                  },
                },
                '& .MuiInputLabel-root': {
                  color: '#808080',
                },
                '& .MuiOutlinedInput-input': {
                  color: 'white',
                },
                backgroundColor: 'rgba(0, 0, 0, 0.2)',
                borderRadius: '8px',
              }}
            />
            <TextField
              fullWidth
              label="Contraseña"
              name="password"
              type="password"
              value={formData.password}
              onChange={handleChange}
              margin="normal"
              required
              sx={{
                '& .MuiOutlinedInput-root': {
                  '& fieldset': {
                    borderColor: '#444444',
                  },
                  '&:hover fieldset': {
                    borderColor: '#666666',
                  },
                  '&.Mui-focused fieldset': {
                    borderColor: '#888888',
                  },
                },
                '& .MuiInputLabel-root': {
                  color: '#808080',
                },
                '& .MuiOutlinedInput-input': {
                  color: 'white',
                },
                backgroundColor: 'rgba(0, 0, 0, 0.2)',
                borderRadius: '8px',
              }}
            />
            <Button
              fullWidth
              variant="contained"
              color="primary"
              type="submit"
              sx={{ 
                mt: 3, 
                mb: 2,
                backgroundColor: '#444444',
                color: 'white',
                borderRadius: '8px',
                '&:hover': {
                  backgroundColor: '#666666'
                },
                textTransform: 'uppercase',
                py: 1.5,
                fontSize: '16px',
                fontWeight: 'bold',
                letterSpacing: '1px',
                boxShadow: '0 4px 10px rgba(0, 0, 0, 0.3)'
              }}
            >
              Iniciar sesión
            </Button>
            
            <Button
              fullWidth
              variant="outlined"
              onClick={handleDemoLogin}
              sx={{ 
                mb: 2,
                borderColor: '#ff4b4b',
                color: '#ff4b4b',
                '&:hover': {
                  borderColor: '#ff758c',
                  backgroundColor: 'rgba(255, 75, 75, 0.05)'
                },
                textTransform: 'uppercase',
                fontWeight: 'bold'
              }}
            >
              Modo Demo (Sin credenciales)
            </Button>
          </form>

          <Divider sx={{ my: 2, borderColor: '#444444', color: '#808080' }}>o</Divider>

          <Button
            fullWidth
            variant="outlined"
            startIcon={<Google />}
            onClick={() => handleSocialLogin('google')}
            sx={{ 
              mb: 2,
              borderColor: '#444444',
              color: 'white',
              '&:hover': {
                borderColor: '#666666',
                backgroundColor: 'rgba(255, 255, 255, 0.05)'
              }
            }}
          >
            Continuar con Google
          </Button>
          <Button
            fullWidth
            variant="outlined"
            startIcon={<Facebook />}
            onClick={() => handleSocialLogin('facebook')}
            sx={{ 
              borderColor: '#444444',
              color: 'white',
              '&:hover': {
                borderColor: '#666666',
                backgroundColor: 'rgba(255, 255, 255, 0.05)'
              }
            }}
          >
            Continuar con Facebook
          </Button>

          <Typography variant="body2" align="center" sx={{ mt: 2, color: '#808080' }}>
            ¿No tienes una cuenta?{' '}
            <Typography
              component="span"
              sx={{ 
                cursor: 'pointer',
                color: '#ff69b4',
                '&:hover': {
                  color: '#ff1493'
                }
              }}
              onClick={() => navigate('/register')}
            >
              Regístrate
            </Typography>
          </Typography>
        </CardContent>
      </Card>
    </Box>
  );
};

export default Login;