import { useState, useRef } from 'react';
import {
  Box,
  Grid,
  Paper,
  List,
  ListItem,
  ListItemAvatar,
  ListItemText,
  Avatar,
  Typography,
  TextField,
  IconButton,
  Badge,
  Divider,
  Menu,
  MenuItem,
  Tooltip,
} from '@mui/material';
import { Send, Circle, CameraAlt, AttachFile, Image, PhotoLibrary, Close } from '@mui/icons-material';

const mockChats = [
  {
    id: 1,
    name: 'Ana García',
    avatar: 'https://source.unsplash.com/random/400x400/?portrait,woman',
    lastMessage: '¡Hola! ¿Cómo estás?',
    unread: 2,
    online: true,
    messages: [
      { id: 1, text: '¡Hola! ¿Cómo estás?', sent: false, time: '10:30' },
      { id: 2, text: '¡Hola! Muy bien, ¿y tú?', sent: true, time: '10:31' },
      { id: 3, text: 'Me encantaría conocerte mejor', sent: false, time: '10:32' }
    ]
  },
  {
    id: 2,
    name: 'Carlos Rodríguez',
    avatar: 'https://source.unsplash.com/random/400x400/?portrait,man',
    lastMessage: '¿Te gustaría salir este fin de semana?',
    unread: 1,
    online: false,
    messages: [
      { id: 1, text: 'Hola, vi que te gusta viajar', sent: true, time: '09:20' },
      { id: 2, text: '¡Sí! Me encanta conocer nuevos lugares', sent: false, time: '09:25' },
      { id: 3, text: '¿Te gustaría salir este fin de semana?', sent: true, time: '09:30' }
    ]
  }
];

const Chat = () => {
  const [chats, setChats] = useState(mockChats);
  const [selectedChat, setSelectedChat] = useState(chats[0]);
  const [newMessage, setNewMessage] = useState('');
  const [anchorEl, setAnchorEl] = useState(null);
  const [selectedImage, setSelectedImage] = useState(null);
  const [showCamera, setShowCamera] = useState(false);
  const [stream, setStream] = useState(null);
  const [expandedImage, setExpandedImage] = useState(null);
  
  const fileInputRef = useRef(null);
  const cameraInputRef = useRef(null);
  const videoRef = useRef(null);
  const canvasRef = useRef(null);

  const handleSendMessage = (e) => {
    e.preventDefault();
    if (!newMessage.trim() && !selectedImage) return;

    const message = {
      id: selectedChat.messages.length + 1,
      text: newMessage,
      sent: true,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      image: selectedImage
    };

    setSelectedChat(prev => ({
      ...prev,
      messages: [...prev.messages, message]
    }));

    setNewMessage('');
    setSelectedImage(null);
  };
  
  const handleAttachClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };
  
  const handleGalleryClick = () => {
    fileInputRef.current.click();
    handleMenuClose();
  };

  const handleCameraClick = async () => {
    handleMenuClose();
    setShowCamera(true);
    
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({ video: true });
      setStream(mediaStream);
      
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
    } catch (err) {
      console.error("Error al acceder a la cámara:", err);
      alert("No se pudo acceder a la cámara. Por favor, verifica los permisos.");
    }
  };
  
  const handleCapture = () => {
    if (videoRef.current && canvasRef.current) {
      const context = canvasRef.current.getContext('2d');
      canvasRef.current.width = videoRef.current.videoWidth;
      canvasRef.current.height = videoRef.current.videoHeight;
      context.drawImage(videoRef.current, 0, 0, canvasRef.current.width, canvasRef.current.height);
      
      const imageDataUrl = canvasRef.current.toDataURL('image/png');
      
      // Detener la transmisión de la cámara
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
        setStream(null);
      }
      
      setShowCamera(false);
      setSelectedImage(imageDataUrl);
      console.log("Imagen capturada y establecida");
    }
  };

  // Añadir una función específica para enviar solo la imagen
  const handleSendImageOnly = () => {
    if (!selectedImage) return;
    
    const message = {
      id: selectedChat.messages.length + 1,
      text: '',
      sent: true,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      image: selectedImage
    };

    setSelectedChat(prev => ({
      ...prev,
      messages: [...prev.messages, message]
    }));

    setSelectedImage(null);
  };
  
  const handleCloseCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
    setShowCamera(false);
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setSelectedImage(e.target.result);
      };
      reader.readAsDataURL(file);
    }
  };
  
  const handleRemoveImage = () => {
    setSelectedImage(null);
  };
  
  const handleImageClick = (imageUrl) => {
    setExpandedImage(expandedImage === imageUrl ? null : imageUrl);
  };

  return (
    <Box sx={{ height: 'calc(100vh - 56px)', display: 'flex', flexDirection: 'row', bgcolor: '#121212', overflow: 'hidden' }}>
      <Grid container>
        <Grid item xs={12} md={4} sx={{ borderRight: 1, borderColor: 'rgba(255, 255, 255, 0.12)', backgroundColor: '#1e1e1e' }}>
          <Paper sx={{ height: '100%', bgcolor: '#1e1e1e', borderRadius: 0 }}>
            <Typography variant="h6" sx={{ p: 2, borderBottom: 1, borderColor: 'rgba(255, 255, 255, 0.12)', color: '#ffffff' }}>
              Mensajes
            </Typography>
            <List sx={{ overflow: 'auto', maxHeight: 'calc(100vh - 130px)', backgroundColor: '#1e1e1e' }}>
              {chats.map((chat) => (
                <ListItem
                  key={chat.id}
                  button
                  selected={selectedChat.id === chat.id}
                  onClick={() => setSelectedChat(chat)}
                  sx={{
                    '&:hover': { backgroundColor: 'rgba(255, 255, 255, 0.08)' },
                    backgroundColor: selectedChat.id === chat.id ? 'rgba(255, 255, 255, 0.16)' : 'inherit',
                    color: '#ffffff'
                  }}
                >
                  <ListItemAvatar>
                    <Badge
                      overlap="circular"
                      anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
                      variant="dot"
                      sx={{
                        '& .MuiBadge-badge': {
                          backgroundColor: chat.online ? '#44b700' : 'grey.500'
                        }
                      }}
                    >
                      <Avatar src={chat.avatar} />
                    </Badge>
                  </ListItemAvatar>
                  <ListItemText
                    primary={chat.name}
                    secondary={chat.lastMessage}
                    primaryTypographyProps={{ color: '#ffffff' }}
                    secondaryTypographyProps={{
                      color: 'rgba(255, 255, 255, 0.7)',
                      noWrap: true,
                      sx: { maxWidth: '200px', fontStyle: 'italic' }
                    }}
                  />
                  {chat.unread > 0 && (
                    <Badge badgeContent={chat.unread} color="primary" sx={{ ml: 2 }} />
                  )}
                </ListItem>
              ))}
            </List>
          </Paper>
        </Grid>

        <Grid item xs={12} md={8}>
          <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
            <Box sx={{ p: 2, borderBottom: 1, borderColor: 'rgba(255, 255, 255, 0.12)', display: 'flex', alignItems: 'center', bgcolor: '#1e1e1e' }}>
              <Avatar src={selectedChat.avatar} sx={{ mr: 2 }} />
              <Box>
                <Typography variant="subtitle1" color="#ffffff">{selectedChat.name}</Typography>
                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                  <Circle
                    sx={{
                      fontSize: 12,
                      color: selectedChat.online ? '#44b700' : 'grey.500',
                      mr: 1
                    }}
                  />
                  <Typography variant="body2" color="rgba(255, 255, 255, 0.7)">
                    {selectedChat.online ? 'En línea' : 'Desconectado'}
                  </Typography>
                </Box>
              </Box>
            </Box>

            <Box sx={{ flexGrow: 1, overflow: 'auto', p: 2, backgroundColor: '#121212', height: 'calc(100vh - 200px)' }}>
              {selectedChat.messages.map((message) => (
                <Box
                  key={message.id}
                  sx={{
                    display: 'flex',
                    justifyContent: message.sent ? 'flex-end' : 'flex-start',
                    mb: 2
                  }}
                >
                  <Paper
                    sx={{
                      p: 1.5,
                      backgroundColor: message.sent ? '#0d47a1' : '#333333',
                      color: message.sent ? '#ffffff' : '#ffffff',
                      maxWidth: '65%',
                      boxShadow: 1,
                      borderRadius: '8px'
                    }}
                  >
                    {message.image && (
                      <Box sx={{ mb: 1 }}>
                        <img 
                          src={message.image} 
                          alt="Imagen compartida" 
                          style={{ 
                            maxWidth: expandedImage === message.image ? '100%' : '150px',
                            maxHeight: expandedImage === message.image ? 'none' : '100px',
                            borderRadius: '4px',
                            cursor: 'pointer',
                            objectFit: 'cover',
                            transition: 'all 0.3s ease'
                          }} 
                          onClick={() => handleImageClick(message.image)}
                        />
                      </Box>
                    )}
                    {message.text && (
                      <Typography variant="body1" sx={{ fontStyle: 'italic' }}>{message.text}</Typography>
                    )}
                    <Typography
                      variant="caption"
                      sx={{
                        display: 'block',
                        textAlign: 'right',
                        mt: 1,
                        opacity: 0.7
                      }}
                    >
                      {message.time}
                    </Typography>
                  </Paper>
                </Box>
              ))}
            </Box>

            <Box sx={{ p: 2, backgroundColor: '#1e1e1e', position: 'sticky', bottom: 0, display: 'flex', flexDirection: 'column', zIndex: 100, borderTop: 1, borderColor: 'rgba(255, 255, 255, 0.12)' }}>
              {showCamera && (
                <Box sx={{ 
                  position: 'absolute', 
                  bottom: '70px', 
                  left: '50%', 
                  transform: 'translateX(-50%)',
                  width: '100%', 
                  maxWidth: '350px',
                  bgcolor: '#000',
                  borderRadius: '8px',
                  overflow: 'hidden',
                  boxShadow: '0 0 20px rgba(0,0,0,0.5)',
                  zIndex: 1000
                }}>
                  <Box sx={{ position: 'relative' }}>
                    <video 
                      ref={videoRef} 
                      autoPlay 
                      style={{ width: '100%', height: 'auto' }} 
                    />
                    <Box sx={{ 
                      display: 'flex', 
                      justifyContent: 'space-between', 
                      p: 2, 
                      bgcolor: 'rgba(0,0,0,0.5)'
                    }}>
                      <IconButton onClick={handleCloseCamera} sx={{ color: 'white' }}>
                        <Close />
                      </IconButton>
                      <IconButton onClick={handleCapture} sx={{ color: 'white' }}>
                        <CameraAlt />
                      </IconButton>
                    </Box>
                  </Box>
                  <canvas ref={canvasRef} style={{ display: 'none' }} />
                </Box>
              )}
              
              {selectedImage && (
                <Box sx={{ mb: 1, position: 'relative', display: 'inline-block', maxHeight: '60px', overflow: 'hidden' }}>
                  <img 
                    src={selectedImage} 
                    alt="Imagen seleccionada" 
                    style={{ maxHeight: '60px', borderRadius: '4px' }} 
                  />
                  <IconButton 
                    size="small" 
                    sx={{ position: 'absolute', top: -10, right: -10, bgcolor: 'rgba(0,0,0,0.6)' }}
                    onClick={handleRemoveImage}
                  >
                    <Close fontSize="small" sx={{ color: 'white' }} />
                  </IconButton>
                </Box>
              )}
              
              <form onSubmit={handleSendMessage} style={{ display: 'flex', backgroundColor: '#1e1e1e', zIndex: 10, padding: '4px 0' }}>
                <TextField
                  fullWidth
                  placeholder="Escribe un mensaje..."
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  variant="outlined"
                  size="small"
                  sx={{ mr: 1, bgcolor: '#333333', input: { color: '#ffffff' }, '& .MuiOutlinedInput-root': { '& fieldset': { borderColor: 'rgba(255, 255, 255, 0.23)' }, '&:hover fieldset': { borderColor: 'rgba(255, 255, 255, 0.5)' } } }}
                />
                <Tooltip title="Tomar foto">
                  <IconButton 
                    color="primary" 
                    onClick={handleCameraClick}
                    sx={{ mr: 1 }}
                  >
                    <CameraAlt />
                  </IconButton>
                </Tooltip>
                <IconButton 
                  color="primary" 
                  onClick={handleAttachClick}
                  sx={{ mr: 1 }}
                >
                  <AttachFile />
                </IconButton>
                <IconButton 
                  type="submit" 
                  color="primary" 
                  disabled={!newMessage.trim() && !selectedImage}
                  sx={{ 
                    color: (!newMessage.trim() && !selectedImage) ? 'rgba(255, 255, 255, 0.3)' : '#2196f3',
                    '&:hover': { bgcolor: 'rgba(33, 150, 243, 0.08)' }
                  }}
                >
                  <Send />
                </IconButton>
                
                <input
                  type="file"
                  accept="image/*"
                  ref={fileInputRef}
                  style={{ display: 'none' }}
                  onChange={handleFileChange}
                />
                <input
                  type="file"
                  accept="image/*"
                  capture="user"
                  ref={cameraInputRef}
                  style={{ display: 'none' }}
                  onChange={handleFileChange}
                />
                
                <Menu
                  anchorEl={anchorEl}
                  open={Boolean(anchorEl)}
                  onClose={handleMenuClose}
                  PaperProps={{
                    sx: { bgcolor: '#333333', color: 'white' }
                  }}
                >
                  <MenuItem onClick={handleCameraClick}>
                    <CameraAlt sx={{ mr: 1 }} /> Tomar foto
                  </MenuItem>
                  <MenuItem onClick={handleGalleryClick}>
                    <PhotoLibrary sx={{ mr: 1 }} /> Galería
                  </MenuItem>
                </Menu>
              </form>
            </Box>
          </Box>
        </Grid>
      </Grid>
    </Box>
  );
};

export default Chat;