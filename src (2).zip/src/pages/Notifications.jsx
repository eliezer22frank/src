import { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  List,
  ListItem,
  ListItemText,
  ListItemAvatar,
  Avatar,
  Divider,
  Chip,
  IconButton,
  Paper,
  Tabs,
  Tab,
  Badge,
  Button,
  Container,
  AppBar,
  Toolbar
} from '@mui/material';
import {
  Notifications as NotificationsIcon,
  Message,
  Favorite,
  Settings,
  Delete,
  ArrowBack,
  CheckCircle,
  Info,
  Warning,
  Error as ErrorIcon
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';

const Notifications = () => {
  const navigate = useNavigate();
  const [tabValue, setTabValue] = useState(0);
  const [notifications, setNotifications] = useState([]);

  // Simular notificaciones
  useEffect(() => {
    // Datos de ejemplo para notificaciones
    const mockNotifications = [
      {
        id: 1,
        type: 'match',
        read: false,
        timestamp: new Date(Date.now() - 1000 * 60 * 5).toISOString(), // 5 minutos atrás
        title: 'Nuevo match',
        message: 'Has hecho match con Laura',
        avatar: 'https://source.unsplash.com/random/100x100/?woman,portrait',
        action: '/matches'
      },
      {
        id: 2,
        type: 'message',
        read: false,
        timestamp: new Date(Date.now() - 1000 * 60 * 30).toISOString(), // 30 minutos atrás
        title: 'Nuevo mensaje',
        message: 'Carlos: Hola, ¿cómo estás?',
        avatar: 'https://source.unsplash.com/random/100x100/?man,portrait',
        action: '/chat'
      },
      {
        id: 3,
        type: 'system',
        read: true,
        timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(), // 2 horas atrás
        title: 'Perfil actualizado',
        message: 'Tu perfil ha sido actualizado correctamente',
        avatar: null,
        action: '/profile'
      },
      {
        id: 4,
        type: 'match',
        read: true,
        timestamp: new Date(Date.now() - 1000 * 60 * 60 * 5).toISOString(), // 5 horas atrás
        title: 'Nuevo match',
        message: 'Has hecho match con Miguel',
        avatar: 'https://source.unsplash.com/random/100x100/?man,portrait,2',
        action: '/matches'
      },
      {
        id: 5,
        type: 'system',
        read: true,
        timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(), // 1 día atrás
        title: 'Bienvenido a la app',
        message: 'Gracias por registrarte. Completa tu perfil para comenzar.',
        avatar: null,
        action: '/profile'
      },
      {
        id: 6,
        type: 'message',
        read: true,
        timestamp: new Date(Date.now() - 1000 * 60 * 60 * 26).toISOString(), // 26 horas atrás
        title: 'Nuevo mensaje',
        message: 'Ana: ¿Te gustaría quedar este fin de semana?',
        avatar: 'https://source.unsplash.com/random/100x100/?woman,portrait,2',
        action: '/chat'
      },
      {
        id: 7,
        type: 'system',
        read: true,
        timestamp: new Date(Date.now() - 1000 * 60 * 60 * 48).toISOString(), // 2 días atrás
        title: 'Actualización de la aplicación',
        message: 'Hemos añadido nuevas funciones. ¡Explóralas ahora!',
        avatar: null,
        action: '/discover'
      },
    ];

    setNotifications(mockNotifications);
  }, []);

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  const handleNotificationClick = (notification) => {
    // Marcar como leída
    setNotifications(prevNotifications =>
      prevNotifications.map(item =>
        item.id === notification.id ? { ...item, read: true } : item
      )
    );

    // Navegar a la acción correspondiente
    if (notification.action) {
      navigate(notification.action);
    }
  };

  const markAllAsRead = () => {
    setNotifications(prevNotifications =>
      prevNotifications.map(item => ({ ...item, read: true }))
    );
  };

  const deleteNotification = (id, event) => {
    event.stopPropagation();
    setNotifications(prevNotifications =>
      prevNotifications.filter(item => item.id !== id)
    );
  };

  const formatTimestamp = (timestamp) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / (1000 * 60));
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

    if (diffMins < 60) {
      return `Hace ${diffMins} ${diffMins === 1 ? 'minuto' : 'minutos'}`;
    } else if (diffHours < 24) {
      return `Hace ${diffHours} ${diffHours === 1 ? 'hora' : 'horas'}`;
    } else {
      return `Hace ${diffDays} ${diffDays === 1 ? 'día' : 'días'}`;
    }
  };

  const getNotificationIcon = (type) => {
    switch (type) {
      case 'match':
        return <Favorite sx={{ color: '#ff4b4b' }} />;
      case 'message':
        return <Message sx={{ color: '#4b96ff' }} />;
      case 'system':
        return <Info sx={{ color: '#4bff4b' }} />;
      default:
        return <NotificationsIcon />;
    }
  };

  const getFilteredNotifications = () => {
    if (tabValue === 0) return notifications;
    const types = ['match', 'message', 'system'];
    return notifications.filter(notification => notification.type === types[tabValue - 1]);
  };

  const unreadCount = notifications.filter(notification => !notification.read).length;

  return (
    <Box sx={{ bgcolor: '#121212', minHeight: '100vh', pb: 7 }}>
      <AppBar position="static" sx={{ bgcolor: '#1e1e1e', boxShadow: 'none' }}>
        <Toolbar>
          <IconButton edge="start" color="inherit" onClick={() => navigate(-1)} sx={{ mr: 2 }}>
            <ArrowBack />
          </IconButton>
          <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
            Notificaciones
          </Typography>
          <Button color="inherit" onClick={markAllAsRead} disabled={unreadCount === 0}>
            Marcar todo como leído
          </Button>
        </Toolbar>
      </AppBar>

      <Container maxWidth="sm" sx={{ pt: 2 }}>
        <Paper sx={{ bgcolor: '#1e1e1e', color: 'white', mb: 2 }}>
          <Tabs
            value={tabValue}
            onChange={handleTabChange}
            variant="fullWidth"
            indicatorColor="secondary"
            textColor="inherit"
            sx={{
              '& .MuiTab-root': {
                color: 'rgba(255, 255, 255, 0.7)',
              },
              '& .Mui-selected': {
                color: '#ff4b4b',
              },
            }}
          >
            <Tab 
              label={
                <Badge badgeContent={unreadCount} color="secondary">
                  <Box sx={{ px: 1 }}>Todas</Box>
                </Badge>
              } 
            />
            <Tab 
              label={
                <Badge 
                  badgeContent={notifications.filter(n => n.type === 'match' && !n.read).length} 
                  color="secondary"
                >
                  <Box sx={{ px: 1 }}>Matches</Box>
                </Badge>
              } 
            />
            <Tab 
              label={
                <Badge 
                  badgeContent={notifications.filter(n => n.type === 'message' && !n.read).length} 
                  color="secondary"
                >
                  <Box sx={{ px: 1 }}>Mensajes</Box>
                </Badge>
              } 
            />
            <Tab 
              label={
                <Badge 
                  badgeContent={notifications.filter(n => n.type === 'system' && !n.read).length} 
                  color="secondary"
                >
                  <Box sx={{ px: 1 }}>Sistema</Box>
                </Badge>
              } 
            />
          </Tabs>
        </Paper>

        {getFilteredNotifications().length > 0 ? (
          <List sx={{ bgcolor: '#1e1e1e', borderRadius: 1 }}>
            {getFilteredNotifications().map((notification, index) => (
              <Box key={notification.id}>
                <ListItem 
                  alignItems="flex-start" 
                  sx={{ 
                    bgcolor: notification.read ? 'transparent' : 'rgba(255, 75, 75, 0.1)',
                    cursor: 'pointer',
                    '&:hover': {
                      bgcolor: 'rgba(255, 255, 255, 0.05)'
                    }
                  }}
                  onClick={() => handleNotificationClick(notification)}
                  secondaryAction={
                    <IconButton edge="end" aria-label="delete" onClick={(e) => deleteNotification(notification.id, e)}>
                      <Delete sx={{ color: 'rgba(255, 255, 255, 0.5)' }} />
                    </IconButton>
                  }
                >
                  <ListItemAvatar>
                    {notification.avatar ? (
                      <Avatar src={notification.avatar} />
                    ) : (
                      <Avatar sx={{ bgcolor: '#333' }}>
                        {getNotificationIcon(notification.type)}
                      </Avatar>
                    )}
                  </ListItemAvatar>
                  <ListItemText
                    primary={
                      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                        <Typography variant="subtitle1" sx={{ color: 'white' }}>
                          {notification.title}
                        </Typography>
                        <Typography variant="caption" sx={{ color: 'rgba(255, 255, 255, 0.6)' }}>
                          {formatTimestamp(notification.timestamp)}
                        </Typography>
                      </Box>
                    }
                    secondary={
                      <Typography variant="body2" sx={{ color: 'rgba(255, 255, 255, 0.7)' }}>
                        {notification.message}
                      </Typography>
                    }
                  />
                </ListItem>
                {index < getFilteredNotifications().length - 1 && (
                  <Divider variant="inset" component="li" sx={{ bgcolor: 'rgba(255, 255, 255, 0.1)' }} />
                )}
              </Box>
            ))}
          </List>
        ) : (
          <Paper sx={{ p: 4, textAlign: 'center', bgcolor: '#1e1e1e', color: 'white' }}>
            <Box sx={{ mb: 2 }}>
              <NotificationsIcon sx={{ fontSize: 60, color: 'rgba(255, 255, 255, 0.3)' }} />
            </Box>
            <Typography variant="h6">No hay notificaciones</Typography>
            <Typography variant="body2" sx={{ color: 'rgba(255, 255, 255, 0.6)', mt: 1 }}>
              Las notificaciones aparecerán aquí cuando tengas nuevos matches, mensajes o actualizaciones del sistema.
            </Typography>
          </Paper>
        )}
      </Container>
    </Box>
  );
};

export default Notifications;