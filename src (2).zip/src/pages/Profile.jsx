import { useState, useRef, useEffect } from 'react';
import {
  Box,
  Container,
  Paper,
  Avatar,
  Typography,
  Button,
  Grid,
  TextField,
  Chip,
  IconButton,
  Stack,
  FormControl,
  OutlinedInput,
  InputLabel,
  Menu,
  MenuItem,
  Tooltip
} from '@mui/material';
import { Edit, AddAPhoto, Add, ArrowBack, CameraAlt, PhotoLibrary, Close } from '@mui/icons-material';

const Profile = () => {
  const [isEditing, setIsEditing] = useState(false);
  const [showCamera, setShowCamera] = useState(false);
  const [stream, setStream] = useState(null);
  const [selectedImage, setSelectedImage] = useState(null);
  const [anchorEl, setAnchorEl] = useState(null);
  
  const fileInputRef = useRef(null);
  const videoRef = useRef(null);
  const canvasRef = useRef(null);

  const [profile, setProfile] = useState({
    name: '',
    age: '',
    bio: '',
    location: '',
    interests: [],
    photos: [
      'https://source.unsplash.com/random/400x400/?portrait',
      'https://source.unsplash.com/random/400x400/?travel',
      'https://source.unsplash.com/random/400x400/?photography'
    ],
    aboutMe: '',
    icebreakers: ['', '', ''],
    searchPreferences: {
      ageRange: [18, 40],
      distance: 25
    },
    sexualOrientation: 'Heterosexual',
    lookingFor: 'Relación seria',
    height: 170,
    bodyType: 'Promedio',
    languages: ['Español', 'Inglés'],
    habits: {
      smoking: 'No',
      drinking: 'Social'
    },
    profession: '',
    education: ''
  });
  
  // Cargar datos del perfil desde localStorage al iniciar
  useEffect(() => {
    const savedProfile = localStorage.getItem('userProfile');
    if (savedProfile) {
      try {
        const parsedProfile = JSON.parse(savedProfile);
        setProfile(prevProfile => ({
          ...prevProfile,
          ...parsedProfile
        }));
      } catch (error) {
        console.error('Error al cargar el perfil:', error);
      }
    }
  }, []);

  const handleEditProfile = () => {
    if (isEditing) {
      // Guardar los cambios en localStorage
      localStorage.setItem('userProfile', JSON.stringify(profile));
      console.log('Guardando cambios:', profile);
    }
    setIsEditing(!isEditing);
  };

  const handleChange = (e) => {
    setProfile({
      ...profile,
      [e.target.name]: e.target.value
    });
  };

  const handleAddInterest = () => {
    // Aquí irá la lógica para agregar intereses
    console.log('Agregando interés');
  };

  const handleRemoveInterest = (interest) => {
    setProfile({
      ...profile,
      interests: profile.interests.filter(i => i !== interest)
    });
  };

  const handlePhotoClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const handleGalleryClick = () => {
    fileInputRef.current.click();
    handleMenuClose();
  };

  const handleCameraClick = async () => {
    handleMenuClose();
    setShowCamera(true);
    
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({ video: true });
      setStream(mediaStream);
      
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
    } catch (err) {
      console.error("Error al acceder a la cámara:", err);
      alert("No se pudo acceder a la cámara. Por favor, verifica los permisos.");
    }
  };

  const handleCapture = () => {
    if (videoRef.current && canvasRef.current) {
      const context = canvasRef.current.getContext('2d');
      canvasRef.current.width = videoRef.current.videoWidth;
      canvasRef.current.height = videoRef.current.videoHeight;
      context.drawImage(videoRef.current, 0, 0, canvasRef.current.width, canvasRef.current.height);
      
      const imageDataUrl = canvasRef.current.toDataURL('image/png');
      
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
        setStream(null);
      }
      
      setShowCamera(false);
      setProfile(prev => ({
        ...prev,
        photos: [imageDataUrl, ...prev.photos.slice(1)]
      }));
    }
  };

  const handleCloseCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
    setShowCamera(false);
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setProfile(prev => ({
          ...prev,
          photos: [e.target.result, ...prev.photos.slice(1)]
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <Box
      sx={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#000000',
        position: 'relative'
      }}
    >
      <Container maxWidth="sm" sx={{ position: 'relative', zIndex: 2 }}>
        <Paper 
          sx={{ 
            p: 0, 
            overflow: 'hidden',
            backgroundColor: '#1e1e1e',
            borderRadius: '8px',
            boxShadow: '0 4px 10px rgba(0, 0, 0, 0.3)',
            color: 'white',
            position: 'relative',
            maxWidth: 400,
            mx: 'auto'
          }}
        >
          {/* Encabezado */}
          <Box sx={{ 
            p: 2, 
            bgcolor: '#333333', 
            display: 'flex', 
            alignItems: 'center',
            borderBottom: '1px solid rgba(128, 128, 128, 0.4)'
          }}>
            <IconButton sx={{ color: 'white' }}>
              <ArrowBack />
            </IconButton>
            <Typography variant="h6" sx={{ color: 'white', fontWeight: 'bold', mx: 'auto' }}>
              Edit Profile
            </Typography>
          </Box>

          <Box sx={{ p: 3 }}>
            {/* Foto de perfil */}
            <Box sx={{ textAlign: 'center', mb: 3, position: 'relative' }}>
              <Box sx={{ position: 'relative', display: 'inline-block' }}>
                <Avatar
                  src={profile.photos[0]}
                  sx={{ 
                    width: 100, 
                    height: 100, 
                    mx: 'auto', 
                    mb: 1
                  }}
                />
                <IconButton
                  onClick={handlePhotoClick}
                  sx={{
                    position: 'absolute',
                    bottom: 0,
                    right: -10,
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    '&:hover': { backgroundColor: 'rgba(0, 0, 0, 0.9)' },
                  }}
                >
                  <AddAPhoto sx={{ color: 'white' }} />
                </IconButton>
              </Box>

              {showCamera && (
                <Box sx={{ 
                  position: 'fixed',
                  top: '50%',
                  left: '50%',
                  transform: 'translate(-50%, -50%)',
                  width: '100%',
                  maxWidth: '400px',
                  bgcolor: '#000',
                  borderRadius: '8px',
                  overflow: 'hidden',
                  boxShadow: '0 0 20px rgba(0,0,0,0.5)',
                  zIndex: 1000
                }}>
                  <Box sx={{ position: 'relative' }}>
                    <video 
                      ref={videoRef} 
                      autoPlay 
                      style={{ width: '100%', height: 'auto' }} 
                    />
                    <Box sx={{ 
                      display: 'flex', 
                      justifyContent: 'space-between', 
                      p: 2, 
                      bgcolor: 'rgba(0,0,0,0.5)'
                    }}>
                      <IconButton onClick={handleCloseCamera} sx={{ color: 'white' }}>
                        <Close />
                      </IconButton>
                      <IconButton onClick={handleCapture} sx={{ color: 'white' }}>
                        <CameraAlt />
                      </IconButton>
                    </Box>
                  </Box>
                  <canvas ref={canvasRef} style={{ display: 'none' }} />
                </Box>
              )}

              <input
                type="file"
                accept="image/*"
                ref={fileInputRef}
                style={{ display: 'none' }}
                onChange={handleFileChange}
              />

              <Menu
                anchorEl={anchorEl}
                open={Boolean(anchorEl)}
                onClose={handleMenuClose}
                PaperProps={{
                  sx: { bgcolor: '#333333', color: 'white' }
                }}
              >
                <MenuItem onClick={handleCameraClick}>
                  <CameraAlt sx={{ mr: 1 }} /> Tomar foto
                </MenuItem>
                <MenuItem onClick={handleGalleryClick}>
                  <PhotoLibrary sx={{ mr: 1 }} /> Galería
                </MenuItem>
              </Menu>
            </Box>

            {/* Formulario */}
            <Box sx={{ px: 1 }}>
              <Typography variant="body2" sx={{ color: '#808080', mb: 0.5, fontWeight: 'bold', fontSize: '0.8rem' }}>
                Name:
              </Typography>
              <FormControl fullWidth variant="outlined" sx={{ mb: 2 }}>
                <OutlinedInput
                  fullWidth
                  placeholder="Name"
                  name="name"
                  value={profile.name}
                  onChange={handleChange}
                  sx={{
                    '&:hover .MuiOutlinedInput-notchedOutline': {
                      borderColor: '#666666',
                    },
                    '& .MuiOutlinedInput-notchedOutline': {
                      borderColor: '#444444',
                      borderWidth: '1px',
                    },
                    '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                      borderColor: '#666666',
                      borderWidth: '2px',
                    },
                    borderRadius: '8px',
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    height: '45px',
                    color: 'white'
                  }}
                />
              </FormControl>

              <Typography variant="body2" sx={{ color: '#808080', mb: 0.5, fontWeight: 'bold', fontSize: '0.8rem' }}>
                Username:
              </Typography>
              <FormControl fullWidth variant="outlined" sx={{ mb: 2 }}>
                <OutlinedInput
                  fullWidth
                  placeholder="Username"
                  name="username"
                  value="devniraj4"
                  onChange={handleChange}
                  sx={{
                    '&:hover .MuiOutlinedInput-notchedOutline': {
                      borderColor: '#666666',
                    },
                    '& .MuiOutlinedInput-notchedOutline': {
                      borderColor: '#444444',
                      borderWidth: '1px',
                    },
                    '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                      borderColor: '#666666',
                      borderWidth: '2px',
                    },
                    borderRadius: '8px',
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    height: '45px',
                    color: 'white'
                  }}
                />
              </FormControl>

              <Typography variant="body2" sx={{ color: '#808080', mb: 0.5, fontWeight: 'bold', fontSize: '0.8rem' }}>
                Email:
              </Typography>
              <FormControl fullWidth variant="outlined" sx={{ mb: 2 }}>
                <OutlinedInput
                  fullWidth
                  placeholder="Email"
                  name="email"
                  value="devniraj4@gmail.com"
                  onChange={handleChange}
                  sx={{
                    '&:hover .MuiOutlinedInput-notchedOutline': {
                      borderColor: '#666666',
                    },
                    '& .MuiOutlinedInput-notchedOutline': {
                      borderColor: '#444444',
                      borderWidth: '1px',
                    },
                    '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                      borderColor: '#666666',
                      borderWidth: '2px',
                    },
                    borderRadius: '8px',
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    height: '45px',
                    color: 'white'
                  }}
                />
              </FormControl>

              <Typography variant="body2" sx={{ color: '#808080', mb: 0.5, fontWeight: 'bold', fontSize: '0.8rem' }}>
                Phone number:
              </Typography>
              <FormControl fullWidth variant="outlined" sx={{ mb: 2 }}>
                <OutlinedInput
                  fullWidth
                  placeholder="Phone number"
                  name="phone"
                  value="123-456-7890"
                  startAdornment={
                    <Box sx={{ display: 'flex', alignItems: 'center', mr: 1 }}>
                      <img src="https://flagcdn.com/w20/us.png" alt="US" style={{ width: 20, height: 15, marginRight: 5 }} />
                      <Typography variant="body2" sx={{ color: 'white', fontSize: '0.8rem' }}>+1</Typography>
                    </Box>
                  }
                  onChange={handleChange}
                  sx={{
                    '&:hover .MuiOutlinedInput-notchedOutline': {
                      borderColor: '#666666',
                    },
                    '& .MuiOutlinedInput-notchedOutline': {
                      borderColor: '#444444',
                      borderWidth: '1px',
                    },
                    '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                      borderColor: '#666666',
                      borderWidth: '2px',
                    },
                    borderRadius: '8px',
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    height: '45px',
                    color: 'white'
                  }}
                />
              </FormControl>

              <Grid container spacing={2}>
                <Grid item xs={6}>
                  <Typography variant="body2" sx={{ color: '#808080', mb: 0.5, fontWeight: 'bold', fontSize: '0.8rem' }}>
                    Country:
                  </Typography>
                  <FormControl fullWidth variant="outlined" sx={{ mb: 2 }}>
                    <OutlinedInput
                      fullWidth
                      placeholder="Country"
                      name="country"
                      value="United States"
                      onChange={handleChange}
                      sx={{
                        '&:hover .MuiOutlinedInput-notchedOutline': {
                          borderColor: '#666666',
                        },
                        '& .MuiOutlinedInput-notchedOutline': {
                          borderColor: '#444444',
                          borderWidth: '1px',
                        },
                        '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                          borderColor: '#666666',
                          borderWidth: '2px',
                        },
                        borderRadius: '8px',
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        height: '45px',
                        color: 'white'
                      }}
                    />
                  </FormControl>
                </Grid>
                <Grid item xs={6}>
                  <Typography variant="body2" sx={{ color: '#808080', mb: 0.5, fontWeight: 'bold', fontSize: '0.8rem' }}>
                    State:
                  </Typography>
                  <FormControl fullWidth variant="outlined" sx={{ mb: 2 }}>
                    <OutlinedInput
                      fullWidth
                      placeholder="State"
                      name="state"
                      value="Florida"
                      onChange={handleChange}
                      sx={{
                        '&:hover .MuiOutlinedInput-notchedOutline': {
                          borderColor: '#666666',
                        },
                        '& .MuiOutlinedInput-notchedOutline': {
                          borderColor: '#444444',
                          borderWidth: '1px',
                        },
                        '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                          borderColor: '#666666',
                          borderWidth: '2px',
                        },
                        borderRadius: '8px',
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        height: '45px',
                        color: 'white'
                      }}
                    />
                  </FormControl>
                </Grid>
              </Grid>

              <Typography variant="body2" sx={{ color: '#808080', mb: 0.5, fontWeight: 'bold', fontSize: '0.8rem' }}>
                Address:
              </Typography>
              <FormControl fullWidth variant="outlined" sx={{ mb: 3 }}>
                <OutlinedInput
                  fullWidth
                  placeholder="Address"
                  name="address"
                  value="45 New Avenue, New York"
                  onChange={handleChange}
                  sx={{
                    '&:hover .MuiOutlinedInput-notchedOutline': {
                      borderColor: '#666666',
                    },
                    '& .MuiOutlinedInput-notchedOutline': {
                      borderColor: '#444444',
                      borderWidth: '1px',
                    },
                    '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                      borderColor: '#666666',
                      borderWidth: '2px',
                    },
                    borderRadius: '8px',
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    height: '45px',
                    color: 'white'
                  }}
                />
              </FormControl>

              {/* Sección de Biografía Expandida */}
              <Typography variant="h6" sx={{ color: 'white', fontWeight: 'bold', mt: 4, mb: 2, borderBottom: '1px solid #444444', pb: 1 }}>
                Biografía Expandida
              </Typography>
              
              <Typography variant="body2" sx={{ color: '#808080', mb: 0.5, fontWeight: 'bold', fontSize: '0.8rem' }}>
                Sobre mí:
              </Typography>
              <FormControl fullWidth variant="outlined" sx={{ mb: 2 }}>
                <OutlinedInput
                  fullWidth
                  multiline
                  rows={4}
                  placeholder="Cuéntanos sobre ti..."
                  name="aboutMe"
                  value={profile.aboutMe}
                  onChange={handleChange}
                  sx={{
                    '&:hover .MuiOutlinedInput-notchedOutline': {
                      borderColor: '#666666',
                    },
                    '& .MuiOutlinedInput-notchedOutline': {
                      borderColor: '#444444',
                      borderWidth: '1px',
                    },
                    '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                      borderColor: '#666666',
                      borderWidth: '2px',
                    },
                    borderRadius: '8px',
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    color: 'white'
                  }}
                />
              </FormControl>

              <Typography variant="body2" sx={{ color: '#808080', mb: 0.5, fontWeight: 'bold', fontSize: '0.8rem' }}>
                Preguntas para romper el hielo:
              </Typography>
              {profile.icebreakers && profile.icebreakers.map((question, index) => (
                <FormControl key={index} fullWidth variant="outlined" sx={{ mb: 1 }}>
                  <OutlinedInput
                    fullWidth
                    placeholder={`Pregunta ${index + 1}`}
                    value={question}
                    onChange={(e) => {
                      const newIcebreakers = [...profile.icebreakers];
                      newIcebreakers[index] = e.target.value;
                      setProfile({
                        ...profile,
                        icebreakers: newIcebreakers
                      });
                    }}
                    sx={{
                      '&:hover .MuiOutlinedInput-notchedOutline': {
                        borderColor: '#666666',
                      },
                      '& .MuiOutlinedInput-notchedOutline': {
                        borderColor: '#444444',
                        borderWidth: '1px',
                      },
                      '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                        borderColor: '#666666',
                        borderWidth: '2px',
                      },
                      borderRadius: '8px',
                      backgroundColor: 'rgba(0, 0, 0, 0.8)',
                      height: '45px',
                      color: 'white'
                    }}
                  />
                </FormControl>
              ))}

              {/* Nota: Las preferencias de búsqueda se han movido a una página separada */}

              {/* Sección de Información Personal */}
              <Typography variant="h6" sx={{ color: 'white', fontWeight: 'bold', mt: 4, mb: 2, borderBottom: '1px solid #444444', pb: 1 }}>
                Información Personal
              </Typography>
              
              <Grid container spacing={2}>
                <Grid item xs={6}>
                  <Typography variant="body2" sx={{ color: '#808080', mb: 0.5, fontWeight: 'bold', fontSize: '0.8rem' }}>
                    Altura (cm):
                  </Typography>
                  <FormControl fullWidth variant="outlined" sx={{ mb: 2 }}>
                    <OutlinedInput
                      fullWidth
                      type="number"
                      placeholder="Altura"
                      name="height"
                      value={profile.height}
                      onChange={handleChange}
                      sx={{
                        '&:hover .MuiOutlinedInput-notchedOutline': {
                          borderColor: '#666666',
                        },
                        '& .MuiOutlinedInput-notchedOutline': {
                          borderColor: '#444444',
                          borderWidth: '1px',
                        },
                        '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                          borderColor: '#666666',
                          borderWidth: '2px',
                        },
                        borderRadius: '8px',
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        height: '45px',
                        color: 'white'
                      }}
                    />
                  </FormControl>
                </Grid>
                <Grid item xs={6}>
                  <Typography variant="body2" sx={{ color: '#808080', mb: 0.5, fontWeight: 'bold', fontSize: '0.8rem' }}>
                    Tipo de cuerpo:
                  </Typography>
                  <FormControl fullWidth variant="outlined" sx={{ mb: 2 }}>
                    <OutlinedInput
                      select
                      fullWidth
                      value={profile.bodyType}
                      onChange={(e) => {
                        setProfile({
                          ...profile,
                          bodyType: e.target.value
                        });
                      }}
                      input={<OutlinedInput />}
                      sx={{
                        '&:hover .MuiOutlinedInput-notchedOutline': {
                          borderColor: '#666666',
                        },
                        '& .MuiOutlinedInput-notchedOutline': {
                          borderColor: '#444444',
                          borderWidth: '1px',
                        },
                        '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                          borderColor: '#666666',
                          borderWidth: '2px',
                        },
                        borderRadius: '8px',
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        height: '45px',
                        color: 'white'
                      }}
                      renderValue={(selected) => selected}
                    >
                      {['Atlético', 'Promedio', 'Delgado', 'Musculoso', 'Robusto', 'Otro'].map((option) => (
                        <MenuItem key={option} value={option}>
                          {option}
                        </MenuItem>
                      ))}
                    </OutlinedInput>
                  </FormControl>
                </Grid>
              </Grid>

              <Typography variant="body2" sx={{ color: '#808080', mb: 0.5, fontWeight: 'bold', fontSize: '0.8rem' }}>
                Idiomas:
              </Typography>
              <Box sx={{ mb: 2 }}>
                <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap>
                  {profile.languages.map((language, index) => (
                    <Chip
                      key={index}
                      label={language}
                      onDelete={() => {
                        setProfile({
                          ...profile,
                          languages: profile.languages.filter((_, i) => i !== index)
                        });
                      }}
                      sx={{ 
                        bgcolor: '#333333', 
                        color: 'white',
                        m: 0.5,
                        '& .MuiChip-deleteIcon': {
                          color: '#999999',
                          '&:hover': {
                            color: 'white'
                          }
                        }
                      }}
                    />
                  ))}
                  <Chip
                    icon={<Add />}
                    label="Añadir"
                    onClick={() => {
                      // Lógica para añadir un nuevo idioma
                      const newLanguage = prompt('Introduce un nuevo idioma');
                      if (newLanguage && !profile.languages.includes(newLanguage)) {
                        setProfile({
                          ...profile,
                          languages: [...profile.languages, newLanguage]
                        });
                      }
                    }}
                    sx={{ 
                      bgcolor: '#444444', 
                      color: 'white',
                      m: 0.5,
                      '&:hover': {
                        bgcolor: '#555555'
                      }
                    }}
                  />
                </Stack>
              </Box>

              <Grid container spacing={2}>
                <Grid item xs={6}>
                  <Typography variant="body2" sx={{ color: '#808080', mb: 0.5, fontWeight: 'bold', fontSize: '0.8rem' }}>
                    Fumar:
                  </Typography>
                  <FormControl fullWidth variant="outlined" sx={{ mb: 2 }}>
                    <OutlinedInput
                      select
                      fullWidth
                      value={profile.habits.smoking}
                      onChange={(e) => {
                        setProfile({
                          ...profile,
                          habits: {
                            ...profile.habits,
                            smoking: e.target.value
                          }
                        });
                      }}
                      input={<OutlinedInput />}
                      sx={{
                        '&:hover .MuiOutlinedInput-notchedOutline': {
                          borderColor: '#666666',
                        },
                        '& .MuiOutlinedInput-notchedOutline': {
                          borderColor: '#444444',
                          borderWidth: '1px',
                        },
                        '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                          borderColor: '#666666',
                          borderWidth: '2px',
                        },
                        borderRadius: '8px',
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        height: '45px',
                        color: 'white'
                      }}
                      renderValue={(selected) => selected}
                    >
                      {['No', 'Ocasionalmente', 'Regularmente', 'Prefiero no decir'].map((option) => (
                        <MenuItem key={option} value={option}>
                          {option}
                        </MenuItem>
                      ))}
                    </OutlinedInput>
                  </FormControl>
                </Grid>
                <Grid item xs={6}>
                  <Typography variant="body2" sx={{ color: '#808080', mb: 0.5, fontWeight: 'bold', fontSize: '0.8rem' }}>
                    Beber:
                  </Typography>
                  <FormControl fullWidth variant="outlined" sx={{ mb: 2 }}>
                    <OutlinedInput
                      select
                      fullWidth
                      value={profile.habits.drinking}
                      onChange={(e) => {
                        setProfile({
                          ...profile,
                          habits: {
                            ...profile.habits,
                            drinking: e.target.value
                          }
                        });
                      }}
                      input={<OutlinedInput />}
                      sx={{
                        '&:hover .MuiOutlinedInput-notchedOutline': {
                          borderColor: '#666666',
                        },
                        '& .MuiOutlinedInput-notchedOutline': {
                          borderColor: '#444444',
                          borderWidth: '1px',
                        },
                        '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                          borderColor: '#666666',
                          borderWidth: '2px',
                        },
                        borderRadius: '8px',
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        height: '45px',
                        color: 'white'
                      }}
                      renderValue={(selected) => selected}
                    >
                      {['No', 'Social', 'Regularmente', 'Prefiero no decir'].map((option) => (
                        <MenuItem key={option} value={option}>
                          {option}
                        </MenuItem>
                      ))}
                    </OutlinedInput>
                  </FormControl>
                </Grid>
              </Grid>

              <Typography variant="body2" sx={{ color: '#808080', mb: 0.5, fontWeight: 'bold', fontSize: '0.8rem' }}>
                Profesión:
              </Typography>
              <FormControl fullWidth variant="outlined" sx={{ mb: 2 }}>
                <OutlinedInput
                  fullWidth
                  placeholder="Profesión"
                  name="profession"
                  value={profile.profession}
                  onChange={handleChange}
                  sx={{
                    '&:hover .MuiOutlinedInput-notchedOutline': {
                      borderColor: '#666666',
                    },
                    '& .MuiOutlinedInput-notchedOutline': {
                      borderColor: '#444444',
                      borderWidth: '1px',
                    },
                    '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                      borderColor: '#666666',
                      borderWidth: '2px',
                    },
                    borderRadius: '8px',
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    height: '45px',
                    color: 'white'
                  }}
                />
              </FormControl>

              <Typography variant="body2" sx={{ color: '#808080', mb: 0.5, fontWeight: 'bold', fontSize: '0.8rem' }}>
                Educación:
              </Typography>
              <FormControl fullWidth variant="outlined" sx={{ mb: 3 }}>
                <OutlinedInput
                  fullWidth
                  placeholder="Educación"
                  name="education"
                  value={profile.education}
                  onChange={handleChange}
                  sx={{
                    '&:hover .MuiOutlinedInput-notchedOutline': {
                      borderColor: '#666666',
                    },
                    '& .MuiOutlinedInput-notchedOutline': {
                      borderColor: '#444444',
                      borderWidth: '1px',
                    },
                    '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                      borderColor: '#666666',
                      borderWidth: '2px',
                    },
                    borderRadius: '8px',
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    height: '45px',
                    color: 'white'
                  }}
                />
              </FormControl>

              {/* Galería de Fotos Mejorada */}
              <Typography variant="h6" sx={{ color: 'white', fontWeight: 'bold', mt: 4, mb: 2, borderBottom: '1px solid #444444', pb: 1 }}>
                Galería de Fotos
              </Typography>
              
              <Grid container spacing={1} sx={{ mb: 3 }}>
                {profile.photos.map((photo, index) => (
                  <Grid item xs={4} key={index}>
                    <Box sx={{ position: 'relative', height: 0, paddingTop: '100%', borderRadius: '8px', overflow: 'hidden' }}>
                      <img 
                        src={photo} 
                        alt={`Foto ${index + 1}`} 
                        style={{ 
                          position: 'absolute', 
                          top: 0, 
                          left: 0, 
                          width: '100%', 
                          height: '100%', 
                          objectFit: 'cover',
                          borderRadius: '8px'
                        }} 
                      />
                      <Box sx={{ 
                        position: 'absolute', 
                        top: 0, 
                        left: 0, 
                        right: 0, 
                        bottom: 0, 
                        backgroundColor: 'rgba(0, 0, 0, 0.3)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        opacity: 0,
                        transition: 'opacity 0.2s',
                        '&:hover': {
                          opacity: 1
                        }
                      }}>
                        <IconButton 
                          size="small" 
                          sx={{ color: 'white', backgroundColor: 'rgba(0, 0, 0, 0.5)' }}
                          onClick={() => {
                            // Lógica para eliminar foto
                            if (profile.photos.length > 1) {
                              setProfile({
                                ...profile,
                                photos: profile.photos.filter((_, i) => i !== index)
                              });
                            }
                          }}
                        >
                          <Close fontSize="small" />
                        </IconButton>
                      </Box>
                    </Box>
                  </Grid>
                ))}
              </Grid>
              
              <Button
                fullWidth
                variant="contained"
                onClick={handleEditProfile}
                sx={{ 
                  mt: 1, 
                  mb: 2, 
                  backgroundColor: '#444444',
                  color: 'white',
                  borderRadius: '8px',
                  '&:hover': {
                    backgroundColor: '#666666'
                  },
                  textTransform: 'uppercase',
                  py: 1.5,
                  fontSize: '16px',
                  fontWeight: 'bold',
                  letterSpacing: '1px',
                  boxShadow: '0 4px 10px rgba(0, 0, 0, 0.3)'
                }}
              >
                SUBMIT
              </Button>
            </Box>
          </Box>
        </Paper>
      </Container>
    </Box>
  );
};

export default Profile;