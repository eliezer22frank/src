import { useState } from 'react';

const Blocked = () => {
  const [blockedUsers, setBlockedUsers] = useState([
    // Aquí se cargarán los usuarios bloqueados desde la base de datos
  ]);

  const handleUnblock = (userId) => {
    // Lógica para desbloquear usuario
    setBlockedUsers(blockedUsers.filter(user => user.id !== userId));
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white p-6">
      <h2 className="text-2xl font-bold mb-6">Usuarios Bloqueados</h2>
      
      {blockedUsers.length === 0 ? (
        <div className="text-center py-8">
          <p className="text-gray-400">No tienes usuarios bloqueados</p>
        </div>
      ) : (
        <div className="grid gap-4">
          {blockedUsers.map(user => (
            <div key={user.id} className="bg-gray-800 p-4 rounded-lg flex items-center justify-between">
              <div className="flex items-center gap-4">
                <img 
                  src={user.profilePicture} 
                  alt={user.name} 
                  className="w-12 h-12 rounded-full object-cover"
                />
                <div>
                  <h3 className="font-semibold">{user.name}</h3>
                  <p className="text-sm text-gray-400">
                    Bloqueado el {new Date(user.blockedDate).toLocaleDateString()}
                  </p>
                </div>
              </div>
              <button
                onClick={() => handleUnblock(user.id)}
                className="bg-red-600 hover:bg-red-700 px-4 py-2 rounded-lg transition-colors"
              >
                Desbloquear
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Blocked;