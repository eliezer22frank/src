import { useState } from 'react';
import { Box, Grid, Card, CardContent, CardMedia, Typography, Button, Stack, Avatar, Paper, Dialog, DialogTitle, DialogContent, DialogActions } from '@mui/material';
import { Chat, Block } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';

const mockMatches = [
  {
    id: 1,
    name: 'Ana García',
    age: 28,
    bio: 'Amante de los viajes y la fotografía',
    image: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&h=400&fit=crop',
    interests: ['Viajes', 'Fotografía', 'Música'],
    matchDate: '2023-08-15',
    lastActive: '2 horas atrás'
  },
  {
    id: 2,
    name: 'Carlos Rodríguez',
    age: 30,
    bio: 'Deportista y amante de la naturaleza',
    image: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=400&h=400&fit=crop',
    interests: ['Deportes', 'Naturaleza', 'Aventura'],
    matchDate: '2023-08-14',
    lastActive: '5 minutos atrás'
  }
];

const Matches = () => {
  const navigate = useNavigate();
  const [matches, setMatches] = useState(mockMatches);
  const [openDialog, setOpenDialog] = useState(false);
  const [selectedMatch, setSelectedMatch] = useState(null);

  const handleStartChat = (matchId) => {
    navigate('/chat');
  };

  const handleBlockUser = (match) => {
    setSelectedMatch(match);
    setOpenDialog(true);
  };

  const handleConfirmBlock = () => {
    if (selectedMatch) {
      // Eliminar el match de la lista
      setMatches(matches.filter(m => m.id !== selectedMatch.id));
      // Guardar el usuario bloqueado en localStorage
      const blockedUsers = JSON.parse(localStorage.getItem('blockedUsers') || '[]');
      blockedUsers.push(selectedMatch);
      localStorage.setItem('blockedUsers', JSON.stringify(blockedUsers));
    }
    setOpenDialog(false);
    setSelectedMatch(null);
  };

  const handleViewProfile = (matchId) => {
    // Aquí irá la lógica para ver el perfil completo
    console.log('Ver perfil:', matchId);
  };

  return (
    <Box sx={{ p: 3, backgroundColor: '#121212', minHeight: '100vh' }}>
      <Typography variant="h4" gutterBottom sx={{ mb: 4, color: '#ffffff' }}>
        Tus Matches
      </Typography>

      <Grid container spacing={3}>
        {matches.map((match) => (
          <Grid item xs={12} sm={6} md={4} key={match.id}>
            <Card sx={{ height: '100%', bgcolor: '#1e1e1e', borderRadius: 2, border: '1px solid rgba(255, 255, 255, 0.12)' }}>
              <CardMedia
                component="img"
                height="300"
                image={match.image}
                alt={match.name}
                sx={{ 
                  cursor: 'pointer',
                  borderRadius: '8px 8px 0 0',
                  objectFit: 'cover'
                }}
                onClick={() => handleViewProfile(match.id)}
              />
              <CardContent sx={{ color: '#ffffff' }}>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <Box sx={{ flexGrow: 1 }}>
                    <Typography variant="h6" gutterBottom sx={{ color: '#ffffff' }}>
                      {match.name}, {match.age}
                    </Typography>
                    <Typography variant="body2" color="rgba(255, 255, 255, 0.7)">
                      Match el {new Date(match.matchDate).toLocaleDateString()}
                    </Typography>
                  </Box>
                  <Typography variant="caption" color="rgba(255, 255, 255, 0.7)">
                    {match.lastActive}
                  </Typography>
                </Box>

                <Typography variant="body2" color="rgba(255, 255, 255, 0.7)" paragraph>
                  {match.bio}
                </Typography>

                <Stack direction="row" spacing={1} flexWrap="wrap" sx={{ mb: 2 }}>
                  {match.interests.map((interest) => (
                    <Typography
                      key={interest}
                      variant="body2"
                      sx={{
                        bgcolor: 'primary.light',
                        color: 'white',
                        px: 1,
                        py: 0.5,
                        borderRadius: 1,
                        mb: 1
                      }}
                    >
                      {interest}
                    </Typography>
                  ))}
                </Stack>

                <Stack direction="row" spacing={2} sx={{ mt: 2 }}>
                  <Button
                    fullWidth
                    variant="contained"
                    color="secondary"
                    startIcon={<Chat />}
                    onClick={() => handleStartChat(match.id)}
                  >
                    Iniciar chat
                  </Button>
                  <Button
                    variant="outlined"
                    color="error"
                    startIcon={<Block />}
                    onClick={() => handleBlockUser(match)}
                  >
                    Bloquear
                  </Button>
                </Stack>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      <Dialog
        open={openDialog}
        onClose={() => setOpenDialog(false)}
        PaperProps={{
          sx: {
            bgcolor: '#1e1e1e',
            color: 'white'
          }
        }}
      >
        <DialogTitle>Confirmar bloqueo</DialogTitle>
        <DialogContent>
          <Typography>
            ¿Estás seguro de que quieres bloquear a {selectedMatch?.name}? Esta acción no se puede deshacer.
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenDialog(false)} color="primary">
            Cancelar
          </Button>
          <Button onClick={handleConfirmBlock} color="error" variant="contained">
            Bloquear
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default Matches;