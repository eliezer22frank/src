import { useState, useEffect } from 'react';
import { Box, Typography, Grid, Container, Card, CardContent, CardMedia, Button } from '@mui/material';
import { Favorite as LikeIcon, Close as DislikeIcon } from '@mui/icons-material';

const mockProfiles = [
  {
    id: 1,
    name: 'María González',
    age: 25,
    imageUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&h=400&fit=crop',
    description: 'Amante de la música y los viajes. Busco alguien con quien compartir aventuras y crear recuerdos inolvidables.',
    goals: 'Quiero viajar por el mundo, aprender nuevos idiomas y crear una familia en el futuro.',
    interests: 'Me encanta la música clásica, el senderismo y la fotografía. Disfruto cocinar y probar nuevas recetas.',
    gallery: [
      'https://images.unsplash.com/photo-1488085061387-422e29b40080?w=400&h=400&fit=crop',
      'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=400&h=400&fit=crop',
      'https://images.unsplash.com/photo-1551632811-561732d1e306?w=400&h=400&fit=crop',
      'https://images.unsplash.com/photo-1556911220-bda9f7f7597e?w=400&h=400&fit=crop',
      'https://images.unsplash.com/photo-1554080353-a576cf803bda?w=400&h=400&fit=crop',
      'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=400&h=400&fit=crop'
    ]
  },
  {
    id: 2,
    name: 'Juan Pérez',
    age: 28,
    imageUrl: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=400&h=400&fit=crop',
    description: 'Deportista y emprendedor. Busco una persona que comparta mi pasión por el deporte y el crecimiento personal.',
    goals: 'Mi meta es crear mi propia empresa y encontrar un equilibrio entre trabajo y vida personal.',
    interests: 'Practico deportes extremos, me encanta la tecnología y disfruto de la buena comida.',
    gallery: [
      'https://images.unsplash.com/photo-1517649763962-0c623066013b?w=400&h=400&fit=crop',
      'https://images.unsplash.com/photo-1518770660439-4636190af475?w=400&h=400&fit=crop',
      'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=400&h=400&fit=crop',
      'https://images.unsplash.com/photo-1530549387789-4c1017266635?w=400&h=400&fit=crop',
      'https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=400&h=400&fit=crop',
      'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=400&h=400&fit=crop'
    ]
  },
  {
    id: 3,
    name: 'Sofía Martínez',
    age: 24,
    imageUrl: 'https://images.unsplash.com/photo-1531123897727-8f129e1688ce?w=400&h=400&fit=crop',
    description: 'Estudiante de arquitectura con pasión por el arte y el diseño. Busco alguien creativo y con visión.',
    goals: 'Quiero terminar mi carrera y viajar por Europa para conocer la arquitectura clásica.',
    interests: 'Me encanta dibujar, visitar museos y la fotografía arquitectónica.',
    gallery: [
      'https://images.unsplash.com/photo-1511818966892-d7d671e672a2?w=400&h=400&fit=crop',
      'https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?w=400&h=400&fit=crop',
      'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=400&h=400&fit=crop',
      'https://images.unsplash.com/photo-1513364776144-60967b0f800f?w=400&h=400&fit=crop',
      'https://images.unsplash.com/photo-1582555172866-f73bb12a2ab3?w=400&h=400&fit=crop',
      'https://images.unsplash.com/photo-1519677100203-a0e668c92439?w=400&h=400&fit=crop'
    ]
  },
  {
    id: 4,
    name: 'Alejandro Torres',
    age: 30,
    imageUrl: 'https://images.unsplash.com/photo-1583195764036-6dc248ac07d9?w=400&h=400&fit=crop',
    description: 'Chef profesional apasionado por la gastronomía internacional. Busco compartir experiencias culinarias.',
    goals: 'Sueño con abrir mi propio restaurante y viajar por el mundo descubriendo nuevos sabores.',
    interests: 'Cocina, vinos, viajes gastronómicos y mercados locales.',
    gallery: [
      'https://images.unsplash.com/photo-1556910103-1c02745aae4d?w=400&h=400&fit=crop',
      'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400&h=400&fit=crop',
      'https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?w=400&h=400&fit=crop',
      'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=400&h=400&fit=crop',
      'https://images.unsplash.com/photo-1533900298318-6b8da08a523e?w=400&h=400&fit=crop',
      'https://images.unsplash.com/photo-1565958011703-44f9829ba187?w=400&h=400&fit=crop'
    ]
  },
  {
    id: 5,
    name: 'Valentina López',
    age: 27,
    imageUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&h=400&fit=crop',
    description: 'Profesora de yoga y meditación. Busco una conexión espiritual y alguien que valore el bienestar.',
    goals: 'Quiero crear un centro de bienestar y retiros espirituales en la naturaleza.',
    interests: 'Yoga, meditación, naturaleza, alimentación consciente y viajes espirituales.',
    gallery: [
      'https://images.unsplash.com/photo-1545205597-3d9d02c29597?w=400&h=400&fit=crop',
      'https://images.unsplash.com/photo-1508672019048-805c876b67e2?w=400&h=400&fit=crop',
      'https://images.unsplash.com/photo-1447752875215-b2761acb3c5d?w=400&h=400&fit=crop',
      'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=400&h=400&fit=crop',
      'https://images.unsplash.com/photo-1531171074112-c2df014354c4?w=400&h=400&fit=crop',
      'https://images.unsplash.com/photo-1503149779833-1de50ebe5f8a?w=400&h=400&fit=crop'
    ]
  },
  {
    id: 6,
    name: 'Diego Ramírez',
    age: 29,
    imageUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop',
    description: 'Ingeniero de software y aficionado a los videojuegos. Busco alguien que comparta mi pasión por la tecnología.',
    goals: 'Desarrollar mi propio videojuego y crear una comunidad de gamers.',
    interests: 'Programación, videojuegos, realidad virtual, cine de ciencia ficción y tecnología.',
    gallery: [
      'https://source.unsplash.com/400x400/?coding',
      'https://source.unsplash.com/400x400/?gaming',
      'https://source.unsplash.com/400x400/?virtual,reality',
      'https://source.unsplash.com/400x400/?sci-fi',
      'https://source.unsplash.com/400x400/?technology',
      'https://source.unsplash.com/400x400/?computer'
    ]
  },
  {
    id: 7,
    name: 'Lucía Fernández',
    age: 26,
    imageUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&h=400&fit=crop',
    description: 'Bailarina profesional y amante de la música. Busco alguien con ritmo y pasión por el arte.',
    goals: 'Crear mi propia academia de danza y viajar con compañías internacionales.',
    interests: 'Danza contemporánea, ballet, música en vivo, teatro y expresión corporal.',
    gallery: [
      'https://source.unsplash.com/400x400/?dance',
      'https://source.unsplash.com/400x400/?ballet',
      'https://source.unsplash.com/400x400/?music,live',
      'https://source.unsplash.com/400x400/?theater',
      'https://source.unsplash.com/400x400/?performance',
      'https://source.unsplash.com/400x400/?art,expression'
    ]
  },
  {
    id: 8,
    name: 'Mateo Sánchez',
    age: 31,
    imageUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&h=400&fit=crop',
    description: 'Fotógrafo de naturaleza y aventurero. Busco una compañera de viaje para explorar el mundo.',
    goals: 'Publicar un libro de fotografía y documentar culturas indígenas alrededor del mundo.',
    interests: 'Fotografía, senderismo, camping, culturas del mundo y conservación ambiental.',
    gallery: [
      'https://source.unsplash.com/400x400/?photography,nature',
      'https://source.unsplash.com/400x400/?hiking',
      'https://source.unsplash.com/400x400/?camping',
      'https://source.unsplash.com/400x400/?culture,indigenous',
      'https://source.unsplash.com/400x400/?conservation',
      'https://source.unsplash.com/400x400/?adventure,travel'
    ]
  }
];

const Discover = () => {
  const [profiles, setProfiles] = useState(mockProfiles);
  
  // Función para manejar el like de un perfil
  const handleLike = (profileId) => {
    console.log('Like a perfil con ID:', profileId);
    // Aquí implementarías la lógica de match
  };

  // Función para manejar el dislike de un perfil
  const handleDislike = (profileId) => {
    console.log('Dislike a perfil con ID:', profileId);
    // Aquí implementarías la lógica para ocultar el perfil
  };

  return (
    <Box sx={{ 
      p: 3, 
      backgroundColor: '#000000', 
      minHeight: '100vh',
      color: 'white'
    }}>
      <Typography variant="h4" gutterBottom sx={{ mb: 4, color: 'white' }}>
        Descubre Nuevas Personas
      </Typography>
      
      <Container maxWidth="md">
        <Grid container spacing={3}>
          {profiles.map((profile) => (
            <Grid item xs={12} sm={6} md={4} key={profile.id}>
              <Card sx={{ 
                height: '100%', 
                backgroundColor: '#121212', 
                color: 'white',
                border: '1px solid #333333',
                borderRadius: '8px',
                transition: 'transform 0.3s ease',
                '&:hover': {
                  transform: 'translateY(-5px)'
                }
              }}>
                <CardMedia
                  component="img"
                  height="250"
                  image={profile.imageUrl || 'https://via.placeholder.com/300'}
                  alt={profile.name}
                  sx={{ objectFit: 'cover' }}
                  loading="lazy"
                />
                <CardContent>
                  <Typography variant="h6" component="div" gutterBottom sx={{ color: 'white' }}>
                    {profile.name}, {profile.age}
                  </Typography>
                  <Typography variant="body2" sx={{ color: '#aaaaaa' }} paragraph>
                    {profile.description}
                  </Typography>
                  
                  <Box sx={{ display: 'flex', justifyContent: 'space-around', mt: 2 }}>
                    <Button
                      variant="contained"
                      color="primary"
                      startIcon={<LikeIcon />}
                      onClick={() => handleLike(profile.id)}
                      size="small"
                    >
                      Like
                    </Button>
                    <Button
                      variant="contained"
                      color="secondary"
                      startIcon={<DislikeIcon />}
                      onClick={() => handleDislike(profile.id)}
                      size="small"
                    >
                      Dislike
                    </Button>
                  </Box>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>
      </Container>
    </Box>
  );
};

export default Discover;