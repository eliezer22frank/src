import { useState } from 'react';
import {
  Container,
  Paper,
  Typography,
  Box,
  Tabs,
  Tab,
  Divider,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Switch,
  FormControlLabel,
  Button,
  TextField,
  IconButton,
  InputAdornment,
  alpha,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
} from '@mui/material';
import {
  Lock,
  Visibility,
  VisibilityOff,
  Security,
  VerifiedUser,
  Notifications,
  Campaign,
  ArrowBack,
  CameraAlt,
  Email,
  Business,
  NotificationsOff,
  Message,
  Favorite,
  Block,
  PersonOff,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';

// Componente TabPanel para mostrar el contenido de cada pestaña
function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`account-tabpanel-${index}`}
      aria-labelledby={`account-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          {children}
        </Box>
      )}
    </div>
  );
}

const AccountCenter = () => {
  const navigate = useNavigate();
  const [tabValue, setTabValue] = useState(0);
  const [showPassword, setShowPassword] = useState(false);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [openDeleteDialog, setOpenDeleteDialog] = useState(false);

  // Estados para los switches de permisos
  const [locationPermission, setLocationPermission] = useState(true);
  const [notificationPermission, setNotificationPermission] = useState(true);
  const [cameraPermission, setCameraPermission] = useState(true);

  // Estados para preferencias de anuncios
  const [personalizedAds, setPersonalizedAds] = useState(true);
  const [emailMarketing, setEmailMarketing] = useState(false);
  const [partnerOffers, setPartnerOffers] = useState(true);
  
  // Estados para configuración de notificaciones
  const [pauseAllNotifications, setPauseAllNotifications] = useState(false);
  const [messageNotifications, setMessageNotifications] = useState(true);
  const [matchNotifications, setMatchNotifications] = useState(true);
  
  // Estado para usuarios bloqueados (datos de ejemplo)
  const [blockedUsers, setBlockedUsers] = useState([
    {
      id: 1,
      name: 'Laura Martínez',
      imageUrl: 'https://randomuser.me/api/portraits/women/44.jpg',
      blockedDate: '15/05/2023'
    },
    {
      id: 2,
      name: 'Carlos Rodríguez',
      imageUrl: 'https://randomuser.me/api/portraits/men/32.jpg',
      blockedDate: '03/06/2023'
    },
    {
      id: 3,
      name: 'Ana García',
      imageUrl: 'https://randomuser.me/api/portraits/women/68.jpg',
      blockedDate: '10/06/2023'
    },
    {
      id: 4,
      name: 'Miguel Torres',
      imageUrl: 'https://randomuser.me/api/portraits/men/45.jpg',
      blockedDate: '22/06/2023'
    }
  ])

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  const handleClickShowPassword = () => {
    setShowPassword(!showPassword);
  };

  const handlePasswordChange = () => {
    // Implementar lógica para cambiar contraseña
    console.log('Cambio de contraseña solicitado');
    // Aquí iría la lógica para validar y cambiar la contraseña
  };

  const handleUnblockUser = (userId) => {
    // Implementar lógica para desbloquear usuario
    console.log('Desbloqueo de usuario solicitado:', userId);
    setBlockedUsers(blockedUsers.filter(user => user.id !== userId));
  };

  return (
    <Container maxWidth="sm" sx={{ py: 4, backgroundColor: '#000000', minHeight: '100vh' }}>
      <Paper elevation={3} sx={{ 
        borderRadius: 2, 
        overflow: 'hidden',
        backgroundColor: '#1e1e1e',
        border: '1px solid rgba(255, 255, 255, 0.1)',
        boxShadow: '0 4px 10px rgba(0, 0, 0, 0.3)'
      }}>
        <Box sx={{ bgcolor: 'primary.main', color: 'white', p: 2, display: 'flex', alignItems: 'center' }}>
          <IconButton color="inherit" onClick={() => navigate(-1)} sx={{ mr: 1 }}>
            <ArrowBack />
          </IconButton>
          <Typography variant="h6" component="h1">
            Centro de cuentas
          </Typography>
        </Box>

        <Box sx={{ borderBottom: 1, borderColor: 'rgba(255, 255, 255, 0.1)' }}>
          <Tabs
            value={tabValue}
            onChange={handleTabChange}
            variant="fullWidth"
            aria-label="account center tabs"
            sx={{
              '& .MuiTab-root': {
                color: 'rgba(255, 255, 255, 0.7)',
                '&.Mui-selected': {
                  color: '#ff4b4b'
                }
              },
              '& .MuiTabs-indicator': {
                backgroundColor: '#ff4b4b'
              }
            }}
          >
            <Tab label="Contraseña y seguridad" />
            <Tab label="Permisos" />
            <Tab label="Preferencias de anuncios" />
            <Tab label="Bloqueados" />
          </Tabs>
        </Box>

        {/* Pestaña de Contraseña y seguridad */}
        <TabPanel value={tabValue} index={0}>
          <Typography variant="h6" gutterBottom sx={{ color: 'white' }}>
            Cambiar contraseña
          </Typography>
          <Box component="form" sx={{ mt: 2 }}>
            <TextField
              margin="normal"
              required
              fullWidth
              name="currentPassword"
              label="Contraseña actual"
              type={showPassword ? 'text' : 'password'}
              id="currentPassword"
              value={currentPassword}
              onChange={(e) => setCurrentPassword(e.target.value)}
              sx={{
                '& .MuiOutlinedInput-root': {
                  '& fieldset': {
                    borderColor: 'rgba(255, 255, 255, 0.23)',
                  },
                  '&:hover fieldset': {
                    borderColor: 'rgba(255, 255, 255, 0.5)',
                  },
                  '&.Mui-focused fieldset': {
                    borderColor: '#ff4b4b',
                  },
                },
                '& .MuiInputLabel-root': {
                  color: 'rgba(255, 255, 255, 0.7)',
                  '&.Mui-focused': {
                    color: '#ff4b4b',
                  },
                },
                '& .MuiInputBase-input': {
                  color: 'white',
                },
              }}
              InputProps={{
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton
                      aria-label="toggle password visibility"
                      onClick={handleClickShowPassword}
                      edge="end"
                    >
                      {showPassword ? <VisibilityOff /> : <Visibility />}
                    </IconButton>
                  </InputAdornment>
                ),
              }}
            />
            <TextField
              margin="normal"
              required
              fullWidth
              name="newPassword"
              label="Nueva contraseña"
              type={showPassword ? 'text' : 'password'}
              id="newPassword"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              sx={{
                '& .MuiOutlinedInput-root': {
                  '& fieldset': {
                    borderColor: 'rgba(255, 255, 255, 0.23)',
                  },
                  '&:hover fieldset': {
                    borderColor: 'rgba(255, 255, 255, 0.5)',
                  },
                  '&.Mui-focused fieldset': {
                    borderColor: '#ff4b4b',
                  },
                },
                '& .MuiInputLabel-root': {
                  color: 'rgba(255, 255, 255, 0.7)',
                  '&.Mui-focused': {
                    color: '#ff4b4b',
                  },
                },
                '& .MuiInputBase-input': {
                  color: 'white',
                },
              }}
            />
            <TextField
              margin="normal"
              required
              fullWidth
              name="confirmPassword"
              label="Confirmar nueva contraseña"
              type={showPassword ? 'text' : 'password'}
              id="confirmPassword"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              sx={{
                '& .MuiOutlinedInput-root': {
                  '& fieldset': {
                    borderColor: 'rgba(255, 255, 255, 0.23)',
                  },
                  '&:hover fieldset': {
                    borderColor: 'rgba(255, 255, 255, 0.5)',
                  },
                  '&.Mui-focused fieldset': {
                    borderColor: '#ff4b4b',
                  },
                },
                '& .MuiInputLabel-root': {
                  color: 'rgba(255, 255, 255, 0.7)',
                  '&.Mui-focused': {
                    color: '#ff4b4b',
                  },
                },
                '& .MuiInputBase-input': {
                  color: 'white',
                },
              }}
            />
            <Button
              type="button"
              fullWidth
              variant="contained"
              sx={{ 
                mt: 3, 
                mb: 2,
                backgroundColor: '#ff4b4b',
                '&:hover': {
                  backgroundColor: alpha('#ff4b4b', 0.8),
                }
              }}
              onClick={handlePasswordChange}
            >
              Actualizar contraseña
            </Button>
          </Box>

          <Divider sx={{ my: 3, backgroundColor: 'rgba(255, 255, 255, 0.1)' }} />

          <Typography variant="h6" gutterBottom sx={{ color: 'white' }}>
            Seguridad de la cuenta
          </Typography>
          <List>
            <ListItem>
              <ListItemIcon>
                <Security />
              </ListItemIcon>
              <ListItemText
                primary="Verificación en dos pasos"
                secondary="Añade una capa extra de seguridad a tu cuenta"
                primaryTypographyProps={{ sx: { color: 'white' } }}
                secondaryTypographyProps={{ sx: { color: 'rgba(255, 255, 255, 0.7)' } }}
              />
              <Switch
                edge="end"
                onChange={(e) => console.log('Verificación en dos pasos:', e.target.checked)}
                checked={false}
                sx={{
                  '& .MuiSwitch-switchBase.Mui-checked': {
                    color: '#ff4b4b',
                    '&:hover': {
                      backgroundColor: alpha('#ff4b4b', 0.1),
                    },
                  },
                  '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track': {
                    backgroundColor: '#ff4b4b',
                  },
                }}
              />
            </ListItem>
          </List>

          <Divider sx={{ my: 3, backgroundColor: 'rgba(255, 255, 255, 0.1)' }} />

          <Typography variant="h6" gutterBottom sx={{ color: 'white' }}>
            Eliminar cuenta
          </Typography>
          <Button
            variant="text"
            size="small"
            startIcon={<PersonOff sx={{ fontSize: 18 }} />}
            onClick={() => setOpenDeleteDialog(true)}
            sx={{
              color: 'rgba(255, 255, 255, 0.5)',
              textTransform: 'none',
              fontSize: '0.875rem',
              '&:hover': {
                color: '#ff4b4b',
                backgroundColor: 'transparent'
              }
            }}
          >
            Eliminar mi cuenta
          </Button>

          <Dialog
            open={openDeleteDialog}
            onClose={() => setOpenDeleteDialog(false)}
            PaperProps={{
              sx: {
                backgroundColor: '#1e1e1e',
                color: 'white',
                border: '1px solid rgba(255, 255, 255, 0.1)'
              }
            }}
          >
            <DialogTitle sx={{ color: 'white' }}>
              ¿Estás seguro de que quieres eliminar tu cuenta?
            </DialogTitle>
            <DialogContent>
              <DialogContentText sx={{ color: 'rgba(255, 255, 255, 0.7)' }}>
                Esta acción no se puede deshacer. Todos tus datos serán eliminados permanentemente.
              </DialogContentText>
            </DialogContent>
            <DialogActions>
              <Button
                onClick={() => setOpenDeleteDialog(false)}
                sx={{ color: 'white' }}
              >
                Cancelar
              </Button>
              <Button
                onClick={() => {
                  console.log('Cuenta eliminada');
                  setOpenDeleteDialog(false);
                }}
                color="error"
                variant="contained"
                sx={{
                  backgroundColor: '#ff4b4b',
                  '&:hover': {
                    backgroundColor: alpha('#ff4b4b', 0.8),
                  }
                }}
              >
                Eliminar cuenta
              </Button>
            </DialogActions>
          </Dialog>

        </TabPanel>

        {/* Pestaña de Permisos */}
        <TabPanel value={tabValue} index={1}>
          <Typography variant="h6" gutterBottom sx={{ color: 'white' }}>
            Permisos de la aplicación
          </Typography>
          <List>
            <ListItem>
              <ListItemIcon>
                <VerifiedUser />
              </ListItemIcon>
              <ListItemText
                primary="Ubicación"
                secondary="Permitir acceso a tu ubicación"
                primaryTypographyProps={{ sx: { color: 'white' } }}
                secondaryTypographyProps={{ sx: { color: 'rgba(255, 255, 255, 0.7)' } }}
              />
              <Switch
                edge="end"
                onChange={(e) => setLocationPermission(e.target.checked)}
                checked={locationPermission}
              />
            </ListItem>
            <Divider variant="inset" component="li" sx={{ backgroundColor: 'rgba(255, 255, 255, 0.1)' }} />
            <ListItem>
              <ListItemIcon>
                <Notifications />
              </ListItemIcon>
              <ListItemText
                primary="Notificaciones"
                secondary="Recibir notificaciones de la aplicación"
                primaryTypographyProps={{ sx: { color: 'white' } }}
                secondaryTypographyProps={{ sx: { color: 'rgba(255, 255, 255, 0.7)' } }}
              />
              <Switch
                edge="end"
                onChange={(e) => setNotificationPermission(e.target.checked)}
                checked={notificationPermission}
                sx={{
                  '& .MuiSwitch-switchBase.Mui-checked': {
                    color: '#ff4b4b',
                    '&:hover': {
                      backgroundColor: alpha('#ff4b4b', 0.1),
                    },
                  },
                  '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track': {
                    backgroundColor: '#ff4b4b',
                  },
                }}
              />
            </ListItem>
            <Divider variant="inset" component="li" sx={{ backgroundColor: 'rgba(255, 255, 255, 0.1)' }} />
            <ListItem>
              <ListItemIcon>
                <CameraAlt />
              </ListItemIcon>
              <ListItemText
                primary="Cámara"
                secondary="Permitir acceso a tu cámara"
                primaryTypographyProps={{ sx: { color: 'white' } }}
                secondaryTypographyProps={{ sx: { color: 'rgba(255, 255, 255, 0.7)' } }}
              />
              <Switch
                edge="end"
                onChange={(e) => setCameraPermission(e.target.checked)}
                checked={cameraPermission}
                sx={{
                  '& .MuiSwitch-switchBase.Mui-checked': {
                    color: '#ff4b4b',
                    '&:hover': {
                      backgroundColor: alpha('#ff4b4b', 0.1),
                    },
                  },
                  '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track': {
                    backgroundColor: '#ff4b4b',
                  },
                }}
              />
            </ListItem>
            
            <Divider sx={{ my: 3, backgroundColor: 'rgba(255, 255, 255, 0.1)' }} />
            
            <Typography variant="h6" gutterBottom sx={{ color: 'white' }}>
              Configuración de notificaciones
            </Typography>
            <List>
              <ListItem>
                <ListItemIcon>
                  <NotificationsOff />
                </ListItemIcon>
                <ListItemText
                  primary="Pausar todas las notificaciones"
                  secondary="Desactiva temporalmente todas las notificaciones"
                  primaryTypographyProps={{ sx: { color: 'white' } }}
                  secondaryTypographyProps={{ sx: { color: 'rgba(255, 255, 255, 0.7)' } }}
                />
                <Switch
                  edge="end"
                  onChange={(e) => setPauseAllNotifications(e.target.checked)}
                  checked={pauseAllNotifications}
                  sx={{
                    '& .MuiSwitch-switchBase.Mui-checked': {
                      color: '#ff4b4b',
                      '&:hover': {
                        backgroundColor: alpha('#ff4b4b', 0.1),
                      },
                    },
                    '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track': {
                      backgroundColor: '#ff4b4b',
                    },
                  }}
                />
              </ListItem>
              <Divider variant="inset" component="li" sx={{ backgroundColor: 'rgba(255, 255, 255, 0.1)' }} />
              <ListItem>
                <ListItemIcon>
                  <Message />
                </ListItemIcon>
                <ListItemText
                  primary="Mensajes"
                  secondary="Recibir notificaciones de mensajes nuevos"
                  primaryTypographyProps={{ sx: { color: 'white' } }}
                  secondaryTypographyProps={{ sx: { color: 'rgba(255, 255, 255, 0.7)' } }}
                />
                <Switch
                  edge="end"
                  onChange={(e) => setMessageNotifications(e.target.checked)}
                  checked={messageNotifications}
                  disabled={pauseAllNotifications}
                  sx={{
                    '& .MuiSwitch-switchBase.Mui-checked': {
                      color: '#ff4b4b',
                      '&:hover': {
                        backgroundColor: alpha('#ff4b4b', 0.1),
                      },
                    },
                    '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track': {
                      backgroundColor: '#ff4b4b',
                    },
                  }}
                />
              </ListItem>
              <Divider variant="inset" component="li" sx={{ backgroundColor: 'rgba(255, 255, 255, 0.1)' }} />
              <ListItem>
                <ListItemIcon>
                  <Favorite />
                </ListItemIcon>
                <ListItemText
                  primary="Matches"
                  secondary="Recibir notificaciones de nuevos matches"
                  primaryTypographyProps={{ sx: { color: 'white' } }}
                  secondaryTypographyProps={{ sx: { color: 'rgba(255, 255, 255, 0.7)' } }}
                />
                <Switch
                  edge="end"
                  onChange={(e) => setMatchNotifications(e.target.checked)}
                  checked={matchNotifications}
                  disabled={pauseAllNotifications}
                  sx={{
                    '& .MuiSwitch-switchBase.Mui-checked': {
                      color: '#ff4b4b',
                      '&:hover': {
                        backgroundColor: alpha('#ff4b4b', 0.1),
                      },
                    },
                    '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track': {
                      backgroundColor: '#ff4b4b',
                    },
                  }}
                />
              </ListItem>
            </List>
          </List>



        </TabPanel>

        {/* Pestaña de Preferencias de anuncios */}
        <TabPanel value={tabValue} index={2}>
          <Typography variant="h6" gutterBottom sx={{ color: 'white' }}>
            Configuración de anuncios
          </Typography>
          <List>
            <ListItem>
              <ListItemIcon>
                <Campaign />
              </ListItemIcon>
              <ListItemText
                primary="Anuncios personalizados"
                secondary="Mostrar anuncios basados en tus intereses"
                primaryTypographyProps={{ sx: { color: 'white' } }}
                secondaryTypographyProps={{ sx: { color: 'rgba(255, 255, 255, 0.7)' } }}
              />
              <Switch
                edge="end"
                onChange={(e) => setPersonalizedAds(e.target.checked)}
                checked={personalizedAds}
              />
            </ListItem>
            <Divider variant="inset" component="li" sx={{ backgroundColor: 'rgba(255, 255, 255, 0.1)' }} />
            <ListItem>
              <ListItemIcon>
                <Email />
              </ListItemIcon>
              <ListItemText
                primary="Correos promocionales"
                secondary="Recibir ofertas y novedades por correo"
                primaryTypographyProps={{ sx: { color: 'white' } }}
                secondaryTypographyProps={{ sx: { color: 'rgba(255, 255, 255, 0.7)' } }}
              />
              <Switch
                edge="end"
                onChange={(e) => setEmailMarketing(e.target.checked)}
                checked={emailMarketing}
              />
            </ListItem>
            <Divider variant="inset" component="li" sx={{ backgroundColor: 'rgba(255, 255, 255, 0.1)' }} />
            <ListItem>
              <ListItemIcon>
                <Business />
              </ListItemIcon>
              <ListItemText
                primary="Ofertas de socios"
                secondary="Recibir ofertas de empresas asociadas"
                primaryTypographyProps={{ sx: { color: 'white' } }}
                secondaryTypographyProps={{ sx: { color: 'rgba(255, 255, 255, 0.7)' } }}
              />
              <Switch
                edge="end"
                onChange={(e) => setPartnerOffers(e.target.checked)}
                checked={partnerOffers}
              />
            </ListItem>
          </List>
        </TabPanel>

        {/* Pestaña de Usuarios Bloqueados */}
        <TabPanel value={tabValue} index={3}>
          <Typography variant="h6" gutterBottom sx={{ color: 'white' }}>
            Usuarios bloqueados
          </Typography>
          {blockedUsers.length > 0 ? (
            <List sx={{ mt: 1 }}>
              {blockedUsers.map((user) => (
                <Paper 
                  key={user.id} 
                  sx={{ 
                    mb: 2, 
                    backgroundColor: '#2a2a2a', 
                    borderRadius: 2,
                    overflow: 'hidden',
                    border: '1px solid rgba(255, 255, 255, 0.1)'
                  }}
                >
                  <ListItem 
                    sx={{ 
                      display: 'flex', 
                      alignItems: 'center', 
                      p: 2 
                    }}
                  >
                    <Box 
                      component="img" 
                      src={user.imageUrl} 
                      alt={user.name}
                      sx={{ 
                        width: 60, 
                        height: 60, 
                        borderRadius: '50%', 
                        mr: 2,
                        objectFit: 'cover',
                        border: '2px solid rgba(255, 255, 255, 0.2)'
                      }} 
                    />
                    <ListItemText
                      primary={user.name}
                      secondary={`Bloqueado desde: ${user.blockedDate}`}
                      primaryTypographyProps={{ sx: { color: 'white', fontWeight: 'medium' } }}
                      secondaryTypographyProps={{ sx: { color: 'rgba(255, 255, 255, 0.6)' } }}
                    />
                    <Button
                      variant="outlined"
                      size="small"
                      startIcon={<PersonOff />}
                      onClick={() => handleUnblockUser(user.id)}
                      sx={{ 
                        borderColor: 'rgba(255, 255, 255, 0.3)',
                        color: 'white',
                        '&:hover': {
                          borderColor: '#ff4b4b',
                          backgroundColor: 'rgba(255, 75, 75, 0.1)'
                        }
                      }}
                    >
                      Desbloquear
                    </Button>
                  </ListItem>
                </Paper>
              ))}
            </List>
          ) : (
            <Box sx={{ 
              display: 'flex', 
              flexDirection: 'column', 
              alignItems: 'center', 
              justifyContent: 'center',
              py: 4,
              px: 2,
              mt: 2,
              backgroundColor: '#2a2a2a',
              borderRadius: 2,
              border: '1px solid rgba(255, 255, 255, 0.1)'
            }}>
              <Block sx={{ fontSize: 60, color: 'rgba(255, 255, 255, 0.2)', mb: 2 }} />
              <Typography variant="h6" align="center" sx={{ color: 'white', mb: 1 }}>
                No tienes usuarios bloqueados
              </Typography>
              <Typography variant="body2" align="center" sx={{ color: 'rgba(255, 255, 255, 0.6)' }}>
                Los usuarios que bloquees aparecerán en esta lista
              </Typography>
            </Box>
          )}
        </TabPanel>
      </Paper>
    </Container>
  );
};

export default AccountCenter;