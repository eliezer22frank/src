# Componentes de Matches

Esta carpeta contiene los componentes relacionados con las coincidencias, likes y gestión de matches.

## Componentes
- Lista de matches
- Tarjetas de perfil
- Indicadores de like/dislike
- Estado de coincidencia