# Componentes de Notificaciones

Esta carpeta contiene los componentes relacionados con las notificaciones y alertas del sistema.

## Componentes
- Lista de notificaciones
- Indicadores de notificaciones no leídas
- Filtros de notificaciones
- Componentes de visualización de notificaciones