# Componentes de Chat

Esta carpeta contiene los componentes relacionados con la funcionalidad de chat y mensajería.

## Componentes
- Lista de conversaciones
- Ventana de chat
- Mensajes individuales
- Indicadores de estado de mensaje