# Componentes de Autenticación

Esta carpeta contiene los componentes relacionados con la autenticación y el registro de usuarios.

## Componentes
- Formularios de inicio de sesión
- Formularios de registro
- Componentes de recuperación de contraseña
- Validación de usuarios