import { useState } from 'react';
import {
  Card,
  CardContent,
  CardMedia,
  Typography,
  Box,
  IconButton,
  Collapse,
  Grid,
  Button,
  Paper,
} from '@mui/material';
import {
  ExpandMore as ExpandMoreIcon,
  Favorite as LikeIcon,
  Close as DislikeIcon,
} from '@mui/icons-material';
import { styled } from '@mui/material/styles';

const ExpandMore = styled((props) => {
  const { expand, ...other } = props;
  return <IconButton {...other} />;
})(({ theme, expand }) => ({
  transform: !expand
    ? 'rotate(0deg)'
    : 'rotate(180deg)',
  marginLeft: 'auto',
  transition: theme.transitions.create('transform', {
    duration: theme.transitions.duration.shortest,
  }),
}));

const ProfileCard = ({ profile }) => {
  const [expanded, setExpanded] = useState(false);

  const handleExpandClick = () => {
    setExpanded(!expanded);
  };

  const handleLike = () => {
    // Implementar lógica de like
    console.log('Like clicked');
  };

  const handleDislike = () => {
    // Implementar lógica de dislike
    console.log('Dislike clicked');
  };

  return (
    <Card sx={{ 
      maxWidth: 400, 
      mx: 'auto', 
      my: 1,
      display: 'flex',
      flexDirection: 'column',
      maxHeight: 'calc(100vh - 120px)', // Ajuste para evitar scroll
      overflow: 'hidden'
    }}>
      <CardMedia
        component="img"
        sx={{
          height: { xs: '200px', sm: '220px', md: '240px' },
          objectFit: 'cover'
        }}
        image={profile?.imageUrl || 'https://via.placeholder.com/300'}
        alt={profile?.name}
      />
      <CardContent sx={{ flex: '0 0 auto', py: 1 }}>
        <Typography variant="h5" component="div" sx={{ mb: 0.5 }}>
          {profile?.name}, {profile?.age}
        </Typography>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 0.5 }}>
          {profile?.description}
        </Typography>
      </CardContent>

      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', py: 0.5 }}>
        <ExpandMore
          expand={expanded}
          onClick={handleExpandClick}
          aria-expanded={expanded}
          aria-label="mostrar más"
          size="small"
        >
          <ExpandMoreIcon fontSize="small" />
        </ExpandMore>
      </Box>

      <Collapse in={expanded} timeout="auto" unmountOnExit sx={{ maxHeight: 'calc(100vh - 400px)', overflow: 'auto' }}>
        <CardContent sx={{ py: 1 }}>
          <Typography variant="h6" sx={{ fontSize: '1rem', mb: 0.5 }}>
            Metas Personales
          </Typography>
          <Typography variant="body2" sx={{ mb: 1 }}>
            {profile?.goals}
          </Typography>

          <Typography variant="h6" sx={{ fontSize: '1rem', mb: 0.5 }}>
            Cosas que Disfruta
          </Typography>
          <Typography variant="body2" sx={{ mb: 1 }}>
            {profile?.interests}
          </Typography>

          <Typography variant="h6" sx={{ fontSize: '1rem', mb: 0.5 }}>
            Galería de Intereses
          </Typography>
          <Grid container spacing={1}>
            {profile?.gallery?.map((image, index) => (
              <Grid item xs={4} key={index}>
                <Paper
                  component="img"
                  src={image}
                  alt={`Interés ${index + 1}`}
                  sx={{ width: '100%', height: 80, objectFit: 'cover' }}
                />
              </Grid>
            ))}
          </Grid>
        </CardContent>
      </Collapse>

      <Box sx={{ 
        display: 'flex', 
        justifyContent: 'space-around', 
        p: 1.5,
        mt: 'auto' // Empuja los botones hacia abajo
      }}>
        <Button
          variant="contained"
          color="primary"
          startIcon={<LikeIcon />}
          onClick={handleLike}
          size="small"
          sx={{ px: 2 }}
        >
          Like
        </Button>
        <Button
          variant="contained"
          color="secondary"
          startIcon={<DislikeIcon />}
          onClick={handleDislike}
          size="small"
          sx={{ px: 2 }}
        >
          Dislike
        </Button>
      </Box>
    </Card>
  );
};

export default ProfileCard;