# Componentes de Perfil

Esta carpeta contiene los componentes relacionados con el perfil de usuario y sus configuraciones.

## Componentes
- Visualización de perfil
- Edición de perfil
- Configuración de cuenta
- Gestión de fotos
- Preferencias de usuario