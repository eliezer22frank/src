# Componentes de Descubrimiento

Esta carpeta contiene los componentes relacionados con la exploración y búsqueda de perfiles.

## Componentes
- Tarjetas de perfil para descubrimiento
- Filtros de búsqueda
- Componentes de interacción (like/dislike)
- Visualización de perfiles sugeridos